var personInfoPanel = {};

personInfoPanel.view;
personInfoPanel.fields = ['personIdDetail', 'personFirstNameDetail', 'personLastNameDetail', 'personMailDetail', 'personBirthDateDetail'];
personInfoPanel.info;
personInfoPanel.rowDetails;

personInfoPanel.createChildren = function () {
}

personInfoPanel.createView = function () {

    var requestReceived = 4;
    var statusReceived = 200;
    var xhttpRequest = new XMLHttpRequest();
    xhttpRequest.onreadystatechange = function () {
        if (this.readyState === requestReceived && this.status === statusReceived) {
            personInfoPanel.view = this.responseText;
        }
    };

    xhttpRequest.open('GET', 'html/personInfoPanel.html',false);
    xhttpRequest.send();
}

personInfoPanel.listenEvents = function () {
    var fields = personInfoPanel.fields;

    document.getElementById('reset')
            .addEventListener('click', function () { onReset();});

    document.getElementById('submit')
            .addEventListener('click', function () { personSubmitted(); });

    eventManager.subscribe('selectRow', onSelectRow);
    eventManager.subscribe('addRow', onAddRow)
}

var onSelectRow = function (details) {
    var headers = personListPanel.columns;
    var fields = personInformationPanel.fields;
    for ( var i = 0; i < fields.length; i++) {
        document.getElementById(fields[i]).value = details[headers[i]];
    }
    personInfoPanel.info = details;
    document.getElementById('personId').style.display = 'none';
    document.getElementById('personIdDetail').style.display = 'none';
}

var onReset = function () {
    var details = personInfoPanel.info;
    var label = personListPanel.columns;
    var headers = personInfoPanel.fields;
    var newId = document.getElementById('personIdDetail').value;
    if (newId == "") {
        for ( var i = 1; i < headers.length; i++) {
            document.getElementById(headers[i]).value = '';
        }
    } else {
        for ( var i = 0; i < headers.length; i++) {
            document.getElementById(headers[i]).value = details[label[i]];
        }
    }
}

var onAddRow = function () {
    var fields = personInfoPanel.fields;
    for ( var i = 0; i < fields.length; i++) {
        document.getElementById(fields[i]).value = "";
    }
    document.getElementById('personId').style.display = 'none';
    document.getElementById('personIdDetail').style.display = 'none';
}

personInfoPanel.setDefault = function () {}

var personSubmitted = function () {
    var fields = personInfoPanel.fields;
    var details = {};
    for ( var i = 0; i < fields.length; i++) {
        details[fields[i]] = document.getElementById(fields[i]).value;
    }
    eventManager.broadcast('submitPerson', details);
}