var personListPanel = {};
var person = {};
var row = {};

personListPanel.personsList;
personListPanel.view;
personListPanel.columns;
personListPanel.row;

personListPanel.createChildren = function () {
}

personListPanel.createView = function () {
// alert(personListPanel.row);
// alert(personListPanel.columns);
// alert(personListPanel.personsList);
// alert(personListPanel.view);

    var requestReceived = 4;
    var statusReceived = 200;
    var xhttpRequest = new XMLHttpRequest();
    xhttpRequest.onreadystatechange = function () {
        if (this.readyState == requestReceived && this.status == statusReceived) {
            personListPanel.view = this.responseText;
        }
    };

    xhttpRequest.open('GET', 'html/personListPanel.html',false);
    xhttpRequest.send();
}

personListPanel.prePopulate = function () {
    person = getPerson();
    personListPanel.constructTable(person);
    personListPanel.personsList = person;
	// alert(personListPanel.personsList);
}

var getPerson = function () {

    var xhttpRequest = new XMLHttpRequest();
    var requestReceived = 4;
    var statusReceived = 200;
    xhttpRequest.onreadystatechange = function () {
        if (this.readyState == requestReceived && this.status == statusReceived) {
            personListPanel.person = JSON.parse(this.responseText);
            // result = xhttpRequest.responseText;
        }
    };

    xhttpRequest.open('GET', '../assets/person.json', false);
    xhttpRequest.send();
    
    return personListPanel.person;
}
// alert(personListPanel.person);
personListPanel.constructTable = function (person) {

    var headers = [];
    for (key in personListPanel.person[0]) {
        if (headers.indexOf(key) === -1) {
            headers.push(key);
        }
    }
    personListPanel.columns = headers;
    var xhttpRequest = new XMLHttpRequest();
    var requestReceived = 4;
    var statusReceived = 200;
    xhttpRequest.onreadystatechange = function () {
        if (this.readyState == requestReceived && this.status == statusReceived) {
            personListPanel.row = this.responseText;
        }
    };

    xhttpRequest.open('GET', '../html/template.html', false);
    xhttpRequest.send();
	personListPanel.populateTable (personListPanel.row,person,headers);
}

personListPanel.populateTable = function (row, person, headers) {
    
    var table = document.getElementById('personTable');
    for (var i = 0; i < person.length; i++) {

        var newRecord = personListPanel.row
			   .replace('Idd', person[i][headers[0]])
                           .replace('Firstname', person[i][headers[1]])
                           .replace('Lastname', person[i][headers[2]])
                           .replace('E-mail', person[i][headers[3]])
                           .replace('Birthdate', person[i][headers[4]])
                           .replace('deleteId', 'delete' + person[i][headers[0]])
                           .replace('rowId', person[i][headers[1]] + person[i][headers[2]])
						   .replace('getRowIndex(0)', 'getRowIndex('+person[i][headers[0]]+')');

        table.innerHTML += newRecord;
		// alert(row);
    }
}
// personListPanel.getRowIndex = function (rowId) {
// personListPanel.onDelete('delete'+rowId);
// alert(rowId);
// }

personListPanel.listenEvents = function (person) {
    var headers = personListPanel.columns;
    var column = personListPanel.columns;
    var personTable = document.getElementById('personTable');
// alert(personListPanel.personsList.length);
    for (var i = 0; i < personListPanel.personsList.length; i++) {
        // var rowId = person[i][headers[1]] + person[i][headers[2]];
		var rowId = personTable.rows[i].length;
        var deleteId = 'delete' + (i + 1);
		alert(deleteId);

	document.getElementById('rowId').addEventListener('click',
            function() {
                personListPanel.fetchRecord(rowId);
            });	
	document.getElementById('delete').addEventListener('click',
            function() {
                personListPanel.onDelete(deleteId);

            });
        var deleteRecord = document.getElementsByClassName('person-delete');

        document.getElementById('add').addEventListener('click',
            function() {
                eventManager.broadcast('addRow');
            });
    }
    eventManager.subscribe('submitPerson', onSubmitPerson);
}
personListPanel.fetchRecord = function (selectedRecord) {
    var data = {};
    var header = personListPanel.columns;
    for (var j = 0; j < header.length; j++) {
        data[header[j]] = selectedRecord.cells[j].innerHTML;
    }
    eventManager.broadcast('selectRow', data);
}

personListPanel.onDelete = function (selectedRecord) {
    var deleteRecord = selectedRecord.parentNode.parentNode;
    deleteRecord.parentNode.removeChild(deleteRecord);
}
var onSubmitPerson = function (details) {
    var record = personListPanel.row;
    var persons = personListPanel.personsList;
    var headers = personListPanel.columns;
    var fields = personInformationPanel.fields;
    var personTable = document.getElementById('personTable');
    var personId = details.personIdDetail;
    if (personId === '') {
        personId = personTable.rows.length;
    }


personListPanel.setDefault = function () {
    var data = [];
    var column = personListPanel.columns;
    var personTable = document.getElementById('personTable');
	// alert(column.length);
    for (var j = 0; j < column.length; j++) {
        data[column[j]] = personTable.rows[1].cells[j].innerHTML;
		alert(column[j]);
    }
    eventManager.broadcast('selectRow', data);
}


    var invalidDetails = personListPanel.validate(details);
    if (invalidDetails) {
        return;
    } else if (invalidDetails != false) {
        for (var i = 0; i < persons.length; i++) {
            for (var j = 1; j < headers.length; j++) {
                if (persons[i][headers[0]] == personId) {
                    personTable.rows[i + 1].cells[j].innerHTML = details[fields[j]];
                }
            }
        }

        if (personId > persons.length) {
            var record = personListPanel.row;
            var personTable = document.getElementById('personTable');
            var newRecord = record.replace('%Id%', personId)
                                  .replace('Firstname', details[fields[1]])
                                  .replace('Lastname', details[fields[2]])
                                  .replace('E-mail', details[fields[3]])
                                  .replace('Birthdate', details[fields[4]])

            personTable.innerHTML += newRecord;
        }
    }
    personListPanel.listenEvents();
}

personListPanel.validate = function (details) {
    var headers = personListPanel.columns;
    for (var j = 1; j < headers.length; j++) {
        if (details[headers[j]] === "") {
            window.alert('enter all the details');
            return false;
        }
    }
}

