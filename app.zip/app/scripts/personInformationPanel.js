var personInformationPanel = {};

personInformationPanel.view;
personInformationPanel.fields = ['id', 'firstName', 'lastName', 'mailId', 'birthDate'];
personInformationPanel.info;

personInformationPanel.createChildren = function () {
}

personInformationPanel.createView = function () {

    var requestReceived = 4;
    var statusReceived = 200;
    var xhttpRequest = new XMLHttpRequest();
    xhttpRequest.onreadystatechange = function () {
        if (this.readyState === requestReceived && this.status === statusReceived) {
            personInformationPanel.view = this.responseText;
            personPanel.container.innerHTML += personInformationPanel.view;
        }
    };

    xhttpRequest.open('GET', 'personInformationPanel.html',false);
    xhttpRequest.send();
}

personInformationPanel.listenEvents = function () {
    var fields = personInformationPanel.fields;

    document.getElementById('reset')
            .addEventListener('click', function () { onReset();});

    document.getElementById('submit')
            .addEventListener('click', function () { personSubmitted(); });

    eventManager.subscribe('selectRow', onSelectRow);
    eventManager.subscribe('addRow', onAddRow)
}

var onSelectRow = function (details) {
    var fields = personInformationPanel.fields;
    for ( var i = 0; i < fields.length; i++) {
        document.getElementById(fields[i]).value = details[fields[i]];
    }
    personInformationPanel.info = details;
    document.getElementById('pId').style.display = 'none';
    document.getElementById('id').style.display = 'none';
}

var onReset = function () {
    var fields = personInformationPanel.fields;
    var newId = document.getElementById('pId').value;
    var details = personInformationPanel.info;
    if (newId == "") {
        for ( var i = 1; i < fields.length; i++) {
            document.getElementById(fields[i]).value = '';
        }
    } else {
        for ( var i = 0; i < fields.length; i++) {
            document.getElementById(fields[i]).value = details[fields[i]];
        }
    }
}

var onAddRow = function () {
    var fields = personInformationPanel.fields;
    for ( var i = 0; i < fields.length; i++) {
        document.getElementById(fields[i]).value = "";
    }
    document.getElementById('pId').style.display = 'none';
    document.getElementById('id').style.display = 'none';
}

personInformationPanel.setDefault = function () {
    // console.log('personInformationPanel setDefault');
    // var fields = personInformationPanel.fields;
    // var personList = document.getElementById('personTable');
    // for ( var i = 0; i < fields.length; i++) {
        // document.getElementById(fields[i]).value = personList.rows[1].cells[i].innerHTML;
    // }
    // eventManager.subscribe('')
}

var personSubmitted = function () {
    var fields = personInformationPanel.fields;
    var details = {};
    for ( var i = 0; i < fields.length; i++) {
        details[fields[i]] = document.getElementById(fields[i]).value;
    }
    eventManager.broadcast('submitPerson', details);
}