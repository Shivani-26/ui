var personPanel = {};
personPanel.view;
personPanel.container;

personPanel.setView = function() {

    var requestReceived = 4;
    var statusReceived = 200;
    var xhttpRequest = new XMLHttpRequest();
    xhttpRequest.onreadystatechange = function () {
        if (this.readyState == requestReceived && this.status == statusReceived) {
            personPanel.view = this.responseText;
        }
    };

    xhttpRequest.open('GET', 'html/personPanel.html',false);
    xhttpRequest.send();
}

personPanel.createChildren = function () {
    personListPanel.createChildren();
    personInfoPanel.createChildren();
}

personPanel.createView = function () {

    personListPanel.createView();
    personInfoPanel.createView();
    document.getElementById('personPanel').innerHTML = personListPanel.view + personInfoPanel.view;

}

personPanel.prePopulate = function () {
    personListPanel.prePopulate();
}

personPanel.listenEvents = function () {
    personListPanel.listenEvents();
    personInfoPanel.listenEvents();
}

personPanel.setDefault = function () {
    personListPanel.setDefault();
    personInfoPanel.setDefault();
}

personPanel.onInit = function () {
    personPanel.createChildren();
    personPanel.createView();
    personPanel.prePopulate();
    personPanel.listenEvents();
    personPanel.setDefault();
}
