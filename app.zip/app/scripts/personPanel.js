var personPanel = {};
personPanel.view;
personPanel.container;

personPanel.createChildren = function () {
    personListPanel.createChildren();
    personInformationPanel.createChildren();
}

personPanel.createView = function () {

    var requestReceived = 4;
    var statusReceived = 200;
    var xhttpRequest = new XMLHttpRequest();
    xhttpRequest.onreadystatechange = function () {
        if (this.readyState == requestReceived && this.status == statusReceived) {
            personPanel.view = this.responseText;
            rsp.container.innerHTML += personPanel.view;
        }
    };

    xhttpRequest.open('GET', 'personPanel.html',false);
    xhttpRequest.send();

    personPanel.container = document.getElementById('personPanel');
    personListPanel.createView();
    personInformationPanel.createView();
}

personPanel.prePopulate = function () {
    personListPanel.prePopulate();
}

personPanel.listenEvents = function () {
    personListPanel.listenEvents();
    personInformationPanel.listenEvents();
}

personPanel.setDefault = function () {
    personListPanel.setDefault();
    personInformationPanel.setDefault();
}

personPanel.onInit = function () {
    personPanel.createChildren();
    personPanel.createView();
    personPanel.prePopulate();
    personPanel.listenEvents();
    personPanel.setDefault();
}