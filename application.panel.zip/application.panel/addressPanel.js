var createAddressPanel = function() { 
    createAddressListPanel();
    createAddressInfomationPanel();
}