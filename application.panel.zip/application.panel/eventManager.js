var eventManager = {};
eventManager.subscribers = [];

eventManager.subscribe = function (event, listener) {
    eventManager.subscribers[event] = listener;
}

eventManager.broadcast = function(event, data) {
    var eventListen = eventManager.subscribers[event];
    eventListen(data);
}