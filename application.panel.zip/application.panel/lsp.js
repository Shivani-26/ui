var lsp = {};
lsp.view;

lsp.createChildren = function() { }

lsp.createView = function() {
      var httpRequest = new XMLHttpRequest();
    httpRequest.onreadystatechange = function(){
    if (this.readyState === 4 && this.setStatus === 200){
        lsp.view = this.responseText;
        app.view.innerHTML += lsp.view;
    }
  };
    httpRequest.open('GET', 'lsp.html', false);
    httpRequest.send();
}

lsp.prepopulate = function() {}

lsp.listenEvents = function() {
    document.getElementById('person').addEventListener('click',
        function(event) {
            eventManager.broadcast('personSelected', 'onSelectPerson');
      }
    )
    document.getElementById('address').addEventListener('click',
        function(event) {
            eventManager.broadcast('addressSelected', 'onSelectAddress');
      }
    )
};

lsp.setDefault = function() {
    eventManager.broadcast('eventSelected');
}
var onLoad = function() {
  app.createChildren();
  app.createView();
  app.prepopulate();
  app.listenEvents();
  app.setDefault();
}
