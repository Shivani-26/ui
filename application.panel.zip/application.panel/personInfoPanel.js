var personInfo = {};
personInfo.createChildren = function() { }

personInfo.createView = function() {
    var httpRequest = new XMLHttpRequest();
    httpRequest.onreadystatechange = function(){
    if (this.readyState === 4 && this.setStatus === 200){
        document.getElementById('sectionDown').innerHTML = this.responseText;
    }
  };
  
    httpRequest.open('GET', 'personInfoPanel.html', true);
    httpRequest.send();
}

personInfo.prePopulate = function {
  
}

personInfo.listenEvents = function() {
  eventManager.subscribe("personSelected", )
}




