// var personList = {};

personList.createChildren = function(){ }


personList.createView = function() {
    var httpRequest = new XMLHttpRequest();
    httpRequest.onreadystatechange = function(){
    if (this.readyState === 4 && this.setStatus === 200){
        document.getElementById('sectionUp').innerHTML = this.responseText;
    }
  };
    httpRequest.open('GET', 'personListPanel.html', true);
    httpRequest.send();
}

personList.getPersonRecord = function() {
    var httpRequest = new XMLHttpRequest();
    httpRequest.onreadystatechange = function(){
    if (this.readyState === 4 && this.setStatus === 200){
        document.getElementById('person').innerHTML = this.responseText;
        prepopulate(person);
    }
  };
    httpRequest.open('GET', 'person.json', true);
    httpRequest.send();
}
}

personList.prepopulate = function (person) {
    var headers = [];
    for (key in person[0]) {
      if(headers.indexOfKey === -1)  {
        headers.push[key];
      }
    }
    
    var httpRequest = new XMLHttpRequest();
    httpRequest.onreadystatechange = function(){
    if (this.readyState === 4 && this.setStatus === 200){
        document.getElementById('person').innerHTML = this.responseText;
        prepopulate();
    }
  };
    httpRequest.open('GET', 'table.html', true);
    httpRequest.send();
}

personList.listenEvents = function() {
    document.getElementById('add').addEventListener('click',
        function(event) {
            eventManager.subscribe('rowSelected', 'table');
        }
    )
}


personList.loadPersonInfo = function(id) {
    eventManager.broadcast("personSelected",id);
}

personList.listenEvents = function() {
    eventManager.trigger("addPersonInfo",personList.addPersonTable);
}

personList.addPersonTable = function(person) {
    for (var eindex = 0; eindex < emp.employees.length; eindex++) {


    }
}
