var rsp = {};

rsp.createChildren = function() {
    person.createChildren();
    address.createChildren();
}
rsp.createView = function(){
    person.createView();
    address.createView();
}
rsp.prepopulate = function(){
    person.prepopulate();
    address.prepopulate();
}

rsp.listenEvents = function() {
    personPanel.listenEvents ();
    addressPanel.listenEvents();
}

rsp.onPersonSelect = function() {
    
}