package com.ofs.training.resource;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.ofs.training.service.AddressService;
import com.ofs.training.service.PersonService;

@Configuration
@ComponentScan(basePackages="com.ofs.training.service")
public class BeanConfig {

    public static AddressService getAddressService() {
        return new AddressService();
    }

@Bean
    public static PersonService getPersonService() {
        return new PersonService();
    }
}