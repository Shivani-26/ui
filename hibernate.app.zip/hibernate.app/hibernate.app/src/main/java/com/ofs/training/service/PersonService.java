package com.ofs.training.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;

import com.ofs.training.resource.BeanConfig;

public class PersonService {
    private static final String PERSON_DELETE = "DELETE FROM person WHERE id = ?";
    private static final String PERSON_UPDATE = "UPDATE person SET firstname = ?, lastname = ?, email = ?, birth_date = ? WHERE id = ?";
    private static final String PERSON_SELECT_ALL = "SELECT id, firstname, lastname, email, birth_date, created_date, address_id FROM person";
    private static final String PERSON_SELECT_ID = "SELECT id, firstname, lastname, email, birth_date, address_id FROM person WHERE id = ?";
    private static final String PERSON_INSERT = "INSERT INTO person (firstname, lastname, email, birth_date, isAdmin, address_id) VALUES(?, ?, ?, ?, ?, ?)";

    @Autowired
    AddressService addressService ;
    
    public PersonService() {}

    public PersonService(AddressService addressService) {
        this.addressService = addressService;
    }

    public void validate(Person person) {

        ArrayList<Error> error = new ArrayList<>();
        int count = 0;

        if (person.getId() == 0) {
            error.add(Error.INVALID_PERSON_ID);
            count++;
        }

        if (person.getFirstname() == null) {
            error.add(Error.INVALID_FIRST_NAME);
            count++;
        }

        if (person.getLastname() == null) {
            error.add(Error.INVALID_LAST_NAME);
            count++;
        }

        if (person.getEmail() == null) {
            error.add(Error.INVALID_EMAIL);
            count++;
        }

        if (person.getBirthDate() == null) {
            error.add(Error.INVALID_BIRTH_DATE);
            count++;
        }

        if (count > 0) {
            throw new AppException(error);
        }
    }

    public Person create(Person person, Connection connection) {

        try {
            String createQuery = PERSON_INSERT;
            validate(person);

            Address addressOne = addressService.create(person.getAddress(), connection);
            long addressId = addressOne.getId();

            PreparedStatement stmt = connection.prepareStatement(createQuery, Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, person.getFirstname());
            stmt.setString(2, person.getLastname());
            stmt.setString(3, person.getEmail());
            stmt.setDate(4, person.getBirthDate());
            stmt.setBoolean(5, person.isAdmin());
            stmt.setLong(6, addressId);
            stmt.executeUpdate();
            ResultSet result = stmt.getGeneratedKeys();
            person.setAddress(addressOne);
            if (result.next()) {
                person.setId(result.getLong(1));
            }

        } catch (SQLException exception) {
            throw new AppException(Error.SQL_EXCEPTION, exception.getCause());
        }
        return person;
    }

    public Person read(Person person, boolean includeAddress, Connection connection) throws Exception {

        try {
            String readQuery = PERSON_SELECT_ID;

            if (person.getId() == 0) {
                throw new AppException(Error.INVALID_PERSON_ID);
            }
            PreparedStatement preparedStatement = connection.prepareStatement(readQuery);
            preparedStatement.setLong(1, person.getId());
            ResultSet result = preparedStatement.executeQuery();

            while (result.next()) {
                person.setId(result.getLong("id"));
                person.setFirstname(result.getString("firstname"));
                person.setLastname(result.getString("lastname"));
                person.setEmail(result.getString("email"));
                person.setBirthDate(result.getDate("birth_date"));
                person.setAddressId(result.getLong("address_id"));

                if (includeAddress) {
                    Address addressReader = new Address();
                    addressReader.setId(result.getLong("address_id"));
                    AddressService addressService = BeanConfig.getAddressService();
                    Address readAddress = addressService.read(addressReader, connection);
                    person.setAddress(readAddress);
                }
            }
            return person;
        } catch (SQLException exception) {
            throw new AppException(Error.SQL_EXCEPTION, exception.getCause());
        }
    }

    public ArrayList<Person> readAll(Connection connection) throws Exception {

        try {
            ArrayList<Person> list = new ArrayList<>();
            String readAllQuery = PERSON_SELECT_ALL;
            PreparedStatement preparedStatement = connection.prepareStatement(readAllQuery);
            ResultSet result = preparedStatement.executeQuery();

            while (result.next()) {
                Person person = new Person();
                person.setId(result.getLong("id"));
                person.setFirstname(result.getString("firstname"));
                person.setLastname(result.getString("lastname"));
                person.setEmail(result.getString("email"));
                person.setBirthDate(result.getDate("birth_date"));
                person.setAddressId(result.getLong("address_id"));

                Address address = new Address();
                address.setId(result.getLong("address_id"));
                AddressService addressService = BeanConfig.getAddressService();
                Address address1 = new Address();
                address1 = addressService.read(address, connection);
                person.setAddress(address1);
                list.add(person);
            }

            return list;
        } catch (SQLException exception) {
            throw new AppException(Error.SQL_EXCEPTION, exception.getCause());
        }
    }

    public Person update(Person person, Connection connection) throws Exception {

        try {
            validate(person);
            String updateQuery = PERSON_UPDATE;

            PreparedStatement preparedStatement = connection.prepareStatement(updateQuery);
            preparedStatement.setString(1, person.getFirstname());
            preparedStatement.setString(2, person.getLastname());
            preparedStatement.setString(3, person.getEmail());
            preparedStatement.setDate(4, person.getBirthDate());
            preparedStatement.setLong(5, person.getId());
            preparedStatement.executeUpdate();

            AddressService addressService = BeanConfig.getAddressService();
            Address addressOne = addressService.update(person.getAddress(), connection);
            person.setAddress(addressOne);
            return person;
        } catch (SQLException exception) {
            throw new AppException(Error.SQL_EXCEPTION, exception.getCause());
        }
    }

    public long delete(long id, Connection connection) throws Exception {

        try {
            if (id == 0) {
                throw new AppException(Error.INVALID_PERSON_ID);
            }
            Person person = new Person();
            person.setId(id);
            person = read(person, true, connection);

            long addressId = person.getAddress().getId();

            String deleteQuery = PERSON_DELETE;

            PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery);
            preparedStatement.setLong(1, person.getId());

            int result = preparedStatement.executeUpdate();

            AddressService addressService = BeanConfig.getAddressService();
            Address address = new Address();
            address.setId(addressId);
            addressService.delete(addressId, connection);
            System.out.println("record sucessfully deleted " + result);
        } catch (SQLException exception) {
            throw new AppException(Error.SQL_EXCEPTION, exception.getCause());
        }
        return id;
    }
    public static void main(String args[]) throws Exception {
        ConnectionManager connector = new ConnectionManager();
        Connection connection = connector.initConnection();

        PersonService ps = BeanConfig.getPersonService();
        Person person = new Person();
        person.setId(2);
        System.out.println(ps.read(person, true, connection));
        System.out.println(ps.readAll(connection));
    }

}
