package com.ofs.training.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ofs.training.resource.JsonUtil;
import com.ofs.training.service.Address;
import com.ofs.training.service.AddressService;
import com.ofs.training.service.ConnectionManager;
import com.ofs.training.service.Person;
import com.ofs.training.service.PersonService;


public class PersonServlet extends HttpServlet {

    /**
     * @author shivani.nagi
     * @since Nov 21, 2018
     */
    private static final long serialVersionUID = 1L;
    ConnectionManager connectionManager = new ConnectionManager();
    Connection conn;
    AddressService addressService = new AddressService();
    Address address = new Address();
    PersonService personService = new PersonService(addressService);

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        PrintWriter printWriter = response.getWriter();
        String id = request.getParameter("id");
        boolean includeAddress = Boolean.parseBoolean(request.getParameter("includeAddress"));
        Person person = new Person();

        if (Objects.isNull(id)) {
            try {
                conn = connectionManager.initConnection();
                ArrayList<Person> persons = new ArrayList<>();
                persons = personService.readAll(conn);
                String personJson = JsonUtil.toJson(persons);
                printWriter.write(personJson);
                connectionManager.releaseConnection(conn, true);
                printWriter.close();
                conn.close();
            } catch (Exception e) {
                connectionManager.releaseConnection(conn, false);
                e.printStackTrace();
            }
        } else {
            try {
                conn = connectionManager.initConnection();
                long rid = Long.parseLong(id);
                person.setId(rid);
                Person readResult = personService.read(person, includeAddress, conn);
                printWriter.write(JsonUtil.toJson(readResult));
                connectionManager.releaseConnection(conn, true);
                conn.close();
            } catch (Exception e1) {
                connectionManager.releaseConnection(conn, false);
                e1.printStackTrace();
            }
        }
    }

    protected void doPut(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        BufferedReader reader = request.getReader();
        List<String> jsonLines = reader.lines().collect(Collectors.toList()); // or
                                                                              // use
                                                                              // readLine()
                                                                              // Method
                                                                              // while
                                                                              // while
                                                                              // block
        String personJson = String.join("", jsonLines); // or use readLine()
                                                        // Method while while
                                                        // block
        Person person = JsonUtil.toObject(personJson, Person.class);
        conn = connectionManager.initConnection();

        try {
            Person createPerson = personService.create(person, conn);
            String createdPerson = JsonUtil.toJson(createPerson);
            PrintWriter printWriter = response.getWriter();
            printWriter.write(createdPerson);
            connectionManager.releaseConnection(conn, true);
        } catch (Exception e) {
            connectionManager.releaseConnection(conn, false);
            e.printStackTrace();
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Reading payload(Input) as JSON using reader
        response.setContentType("application/json");
        BufferedReader reader = request.getReader();
        List<String> jsonLines = reader.lines().collect(Collectors.toList()); // or
                                                                              // use
                                                                              // readLine()
                                                                              // Method
                                                                              // while
                                                                              // while
                                                                              // block
        String personJson = String.join("", jsonLines); // or use readLine()
                                                        // Method while while
                                                        // block
        Person person = JsonUtil.toObject(personJson, Person.class);
        conn = connectionManager.initConnection();
        try {
            Person updatePerson = personService.update(person, conn);
            String updatedPerson = JsonUtil.toJson(updatePerson);
            PrintWriter printWriter = response.getWriter();
            printWriter.write(updatedPerson);
            connectionManager.releaseConnection(conn, true);
        } catch (Exception e) {
            connectionManager.releaseConnection(conn, false);
            e.printStackTrace();
        }
    }

    protected void doDelete(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter printWriter = response.getWriter();
        String id = request.getParameter("id");
        long parsedId = Long.parseLong(id);
        // Address address = new Address();
        // address.setId(parsedId);

        try {
            conn = connectionManager.initConnection();
            long deletedId = personService.delete(parsedId, conn);
            printWriter.println(deletedId);
            connectionManager.releaseConnection(conn, true);
        } catch (Exception e) {
            connectionManager.releaseConnection(conn, false);
            e.printStackTrace();
        }
    }
}
