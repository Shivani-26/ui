package com.ofs.training.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.springframework.stereotype.Service;

@Service
public class AddressService {

    private static final String ADDRESS_SELECT_ID = "SELECT id, street, city, postal_code FROM address WHERE id = ?";
    private static final String ADDRESS_INSERT = "INSERT INTO address(street, city, postal_code) VALUES(?, ?, ?)";
    private static final String ADDRESS_UPDATE = "UPDATE address SET street = ?, city = ?, postal_code = ? WHERE id = ?";
    private static final String ADDRESS_SELECT_ALL = "SELECT id, street, city, postal_code FROM address";
    private static final String ADDRESS_DELETE = "DELETE FROM address WHERE id = ?";
    Address address;

    public void validate(Address address, Connection connection) {

        ArrayList<Error> errorList = new ArrayList<>();
        int count = 0;

        if (address.getId() == 0) {
            errorList.add(Error.INVALID_ADDRESS_ID);
            count++;
        }

        if (address.getStreet() == null) {
            errorList.add(Error.INVALID_STREET);
            count++;
        }

        if (address.getCity() == null) {
            errorList.add(Error.INVALID_CITY);
            count++;
        }

        if (address.getPostalCode() == null) {
            errorList.add(Error.INVALID_POSTAL_CODE);
            count++;
        }

        if (count > 0) {
            throw new AppException(errorList);
        }
    }

    public Address create(Address address) {

        try {
            Connection connection = ConnectionManager.initConnection();
            String query = ADDRESS_INSERT;
            validate(address, connection);

            PreparedStatement statement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, address.getStreet());
            statement.setString(2, address.getCity());
            statement.setInt(3, address.getPostalCode());
            statement.executeUpdate();
            ResultSet result = statement.getGeneratedKeys();

            if (result.next()) {
                address.setId(result.getLong(1));
            }
            return address;
        } catch (SQLException exception) {
            throw new AppException(Error.SQL_EXCEPTION, exception.getCause());
        }
    }

    public Address update(Address address) throws Exception {

        try {
            Connection connection = ConnectionManager.initConnection();
            validate(address, connection);
            String query = ADDRESS_UPDATE;

            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setString(1, address.getStreet());
            stmt.setString(2, address.getCity());
            stmt.setInt(3, address.getPostalCode());
            stmt.setLong(4, address.getId());
            stmt.executeUpdate();
            return address;
        } catch (SQLException exception) {
            throw new AppException(Error.SQL_EXCEPTION, exception.getCause());
        }
    }

    public ArrayList<Address> readAll() throws Exception {

        try {
            Connection connection = ConnectionManager.initConnection();
            ArrayList<Address> records = new ArrayList<>();
            String select = ADDRESS_SELECT_ALL;
            PreparedStatement pstmt = connection.prepareStatement(select);
            ResultSet result = pstmt.executeQuery();
            while (result.next()) {
                Address address = new Address();
                address.setId(result.getInt("id"));
                address.setStreet(result.getString("street"));
                address.setCity(result.getString("city"));
                address.setPostalCode(result.getInt("postal_code"));
                records.add(address);
            }

            System.out.println(records);
            pstmt.close();
            return records;
        } catch (SQLException exception) {
            throw new AppException(Error.SQL_EXCEPTION, exception.getCause());
        }
    }

    public Address read(Address address) throws Exception {

        try {
            String select = ADDRESS_SELECT_ID;
            Connection connection = ConnectionManager.initConnection();

            if (address.getId() == 0) {
                throw new AppException(Error.INVALID_ADDRESS_ID);
            }
            PreparedStatement pstmt = connection.prepareStatement(select);
            pstmt.setLong(1, address.getId());
            ResultSet result = pstmt.executeQuery();

            result.next();
            address.setId(result.getLong("id"));
            address.setStreet(result.getString("street"));
            address.setCity(result.getString("city"));
            address.setPostalCode(result.getInt("postal_code"));
            return address;
        } catch (SQLException exception) {
            throw new AppException(Error.SQL_EXCEPTION, exception.getCause());
        }
    }

    public long delete(long id) throws Exception {

        try {
            String delete = ADDRESS_DELETE;
            Connection connection = ConnectionManager.initConnection();
            if (id == 0) {
                throw new AppException(Error.INVALID_ADDRESS_ID);
            }

            PreparedStatement statement = connection.prepareStatement(delete);
            statement.setLong(1, id);

            int resultSet = statement.executeUpdate();
            System.out.println("record sucessfully deleted " + resultSet);
        } catch (SQLException exception) {
            throw new AppException(Error.SQL_EXCEPTION, exception.getCause());
        }
        return id;
    }
}

