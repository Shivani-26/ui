package com.ofs.training.service;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class ConnectionManager {

    public static Connection initConnection() {

        Connection conn = null;
        try {
            Properties property = new Properties();
            InputStream input = ConnectionManager.class.getResourceAsStream("Connection.properties");
            property.load(input);
            String url = "jdbc:mysql://pc1620:3306/shivani_nagi?useSSL=false";
            conn = DriverManager.getConnection(url, property);
            conn.setAutoCommit(false);
            input.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conn;
    }

    public static void releaseConnection(Connection connection, boolean doCommit) {
        try {
            if (doCommit) {
                connection.commit();
                connection.close();
            } else {
                connection.rollback();
                connection.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    // public static void main(String[] args) {
    // ConnectionManager con = new ConnectionManager();
    // con.initConnection();
    // }
}
