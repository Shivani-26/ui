package com.ofs.training.servlet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ofs.training.service.Address;
import com.ofs.training.service.AddressService;

@Controller
public class AddressController {

    @Autowired
    AddressService addressService;

    @RequestMapping(value = "/address", method = RequestMethod.GET)
    protected ResponseEntity<Address> doGetAll(@RequestBody Address address) throws Exception {
        addressService.readAll();
        return new ResponseEntity<Address>(address, HttpStatus.OK);
        
    }
    @RequestMapping(value = "/address?id= {id}", method = RequestMethod.GET)
    protected ResponseEntity<Address> doGet(@RequestBody Address address, @PathVariable ("id") long id) throws Exception {
        addressService.read(address);
        return new ResponseEntity<Address>(address, HttpStatus.OK);
        
    }
    @RequestMapping(value = "/address?id= {id}", method = RequestMethod.POST)
    protected ResponseEntity<Address> doPost(@RequestBody Address address, @PathVariable ("id") long id) throws Exception {
        addressService.update(address);
        return new ResponseEntity<Address>(address, HttpStatus.OK);
        
    }
    @RequestMapping(value = "/address", method = RequestMethod.POST)
    protected ResponseEntity<Address> doPut(@RequestBody Address address) throws Exception {
        addressService.create(address);
        return new ResponseEntity<Address>(address, HttpStatus.OK);
        
    }
    @RequestMapping(value = "/address?id= {id}", method = RequestMethod.POST)
    protected ResponseEntity<Address> doDelete(@RequestBody Address address, @PathVariable ("id") long id) throws Exception {
                addressService.delete(id);
                return new ResponseEntity<Address>(address, HttpStatus.OK);
    }

}
