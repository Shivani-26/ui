package com.ofs.training.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ofs.training.resource.JsonUtil;
import com.ofs.training.service.AddressService;
import com.ofs.training.service.ConnectionManager;
import com.ofs.training.service.Person;
import com.ofs.training.service.PersonService;

@RestController
public class PersonController{

    /**
     * @author shivani.nagi
     * @since Nov 21, 2018
     */
    @Autowired
    AddressService addressService ;
    PersonService personService = new PersonService(addressService);

    @RequestMapping(value = "/person", method = RequestMethod.GET)
    protected ResponseEntity<Person> doGetAll(@RequestBody Person person) throws Exception {
        personService.readAll();
        return new ResponseEntity<Person>(person, HttpStatus.OK);
        
    }
    @RequestMapping(value = "/person?id= {id}", method = RequestMethod.GET)
    protected ResponseEntity<Person> doGet(@RequestBody Person person, @PathVariable ("id") long id) throws Exception {
        personService.read(person, true);
        return new ResponseEntity<Person>(person, HttpStatus.OK);
        
    }
    @RequestMapping(value = "/person?id= {id}", method = RequestMethod.POST)
    protected ResponseEntity<Person> doPost(@RequestBody Person person, @PathVariable ("id") long id) throws Exception {
        personService.update(person);
        return new ResponseEntity<Person>(person, HttpStatus.OK);
        
    }
    @RequestMapping(value = "/person", method = RequestMethod.POST)
    protected ResponseEntity<Person> doPut(@RequestBody Person person) throws Exception {
        personService.create(person);
        return new ResponseEntity<Person>(person, HttpStatus.OK);
        
    }
    @RequestMapping(value = "/person?id= {id}", method = RequestMethod.POST)
    protected ResponseEntity<Person> doDelete(@RequestBody Person person, @PathVariable ("id") long id) throws Exception {
                personService.delete(id);
                return new ResponseEntity<Person>(person, HttpStatus.OK);
    }

}
