var addressPanel = {};
addressPanel.view;

addressPanel.createChildren = function () {
    addressListPanel.createChildren();
    addressInfoPanel.createChildren();
}

addressPanel.createView = function () {
    addressListPanel.createView();
    addressInfoPanel.createView();
}

addressPanel.prePopulate = function () {
    addressListPanel.prePopulate();
    addressInfoPanel.prePopulate();
}

addressPanel.listenEvents = function () {
    addressListPanel.listenEvents();
    addressInfoPanel.listenEvents();
}

addressPanel.setDefault = function () {
    addressListPanel.setDefault();
    addressInformationPanel.setDefault();
}

addressPanel.onInit = function () {
    addressPanel.createChildren();
    addressPanel.createView();
    addressPanel.prePopulate();
    addressPanel.listenEvent();
    addressPanel.setDefault();
}