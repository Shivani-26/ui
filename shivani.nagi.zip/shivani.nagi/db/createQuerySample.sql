CREATE TABLE edu_univ
							(univ_code CHAR(4) PRIMARY KEY 
							, univ_name VARCHAR(100) NOT NULL
							)
							
							

					
CREATE TABLE edu_dept
							(dept_code CHAR(4) PRIMARY KEY 
							, univ_code CHAR(4) NOT NULL
							, dept_name VARCHAR(50) NOT NULL
							, CONSTRAINT fk_univ_dept FOREIGN KEY (univ_code) 
							REFERENCES edu_univ(univ_code) 
							);								
CREATE TABLE edu_college
			 					(id INT PRIMARY KEY AUTO_INCREMENT
			 					, univ_code CHAR(4) NOT NULL
			 					, col_code CHAR(4) NOT NULL 
			 					, col_name VARCHAR(100) NOT NULL 
			 					, city VARCHAR(50) NOT NULL
			 					, state VARCHAR(50) NOT NULL
			 					, year_opened year(4) NOT NULL
			 					, CONSTRAINT fk_univ_college FOREIGN KEY (univ_code) 
							     REFERENCES edu_univ(univ_code) 
								 );
CREATE TABLE edu_cdept								 				
							(cdept_id INT PRIMARY KEY AUTO_INCREMENT NOT NULL
							, udept_code CHAR(4) NOT NULL 
							, college_id INT NOT NULL
							, CONSTRAINT fk_dept_cdept FOREIGN KEY (udept_code) 
							  REFERENCES edu_dept(dept_code) 
							, CONSTRAINT fk_college_cdept FOREIGN KEY (college_id) 
							  REFERENCES edu_college(id)
							 ); 
							
		
CREATE TABLE edu_designation
									 (id INT PRIMARY KEY AUTO_INCREMENT
									 , `name` VARCHAR(30) NOT NULL
									 , rank CHAR(1) NOT NULL
									 );						
CREATE TABLE edu_employee
								 (id INT PRIMARY KEY AUTO_INCREMENT
								 , college_id INT 
								 , cdept_id INT
								 , desig_id INT
								 , `name` VARCHAR(30) NOT NULL 
								 , dob DATE NULL
								 , email VARCHAR(50) NOT NULL
								 , phone BIGINT NOT NULL
								 , CONSTRAINT fk_college_employee FOREIGN KEY (college_id) 
							      REFERENCES edu_college(id)
								 , CONSTRAINT fk_cdept_employee FOREIGN KEY (cdept_id) 
							      REFERENCES edu_cdept(cdept_id)
								 , CONSTRAINT fk_designation_employee FOREIGN KEY (desig_id) 
							      REFERENCES edu_designation(id) 
									 )	;

CREATE TABLE edu_professor_syllabus
										(emp_id INT 
										, syl_id INT
										, semester TINYINT NOT NULL
										, CONSTRAINT fk_employee_prof_syl FOREIGN KEY (emp_id) 
							           REFERENCES edu_employee(id)
							         , CONSTRAINT fk_syllabus_prof_syl FOREIGN KEY (syl_id) 
							           REFERENCES edu_syllabus(id)
										);
CREATE TABLE edu_student
								 (id INT PRIMARY KEY AUTO_INCREMENT
								 , college_id INT 
								 , cdept_id INT
								 , roll_no CHAR(8) NOT NULL
								 , `name` VARCHAR(100) NOT NULL 
								 , dob DATE NULL
								 , gender CHAR(1)
								 , email VARCHAR(50) NOT NULL
								 , phone BIGINT NOT NULL
								 , address VARCHAR(200) NOT NULL
								 , academic_year YEAR(4) NOT NULL
								 , CONSTRAINT fk_college_student FOREIGN KEY (college_id) 
							      REFERENCES edu_college(id)
								 , CONSTRAINT fk_cdept_student FOREIGN KEY (cdept_id) 
							      REFERENCES edu_cdept(cdept_id)
								 )	;	
								 
CREATE TABLE edu_semester_fee
										(cdept_id INT
										, stud_id INT
										, semester TINYINT NOT NULL
										, amount DOUBLE(18,2) NULL
										, paid_year YEAR(4) NULL
										, paid_status VARCHAR(10) NOT NULL
								      , CONSTRAINT fk_cdept_sem_fee FOREIGN KEY (cdept_id) 
							           REFERENCES edu_cdept(cdept_id)
							         , CONSTRAINT fk_student_sem_fee FOREIGN KEY (stud_id) 
							           REFERENCES edu_student(id)
										);																																		
CREATE TABLE edu_semester_result
										(stud_id INT 
										, syl_id INT
										, semester TINYINT NOT NULL
										, grade VARCHAR(2) NOT NULL
										, credits FLOAT NOT NULL
										, result_date DATE NOT NULL
										, CONSTRAINT fk_student_sem_result FOREIGN KEY (stud_id)
										REFERENCES edu_student(id)
										, CONSTRAINT fk_syl_sem_result FOREIGN KEY(syl_id)
										REFERENCES edu_syllabus(id)
										);
										
CREATE TABLE edu_syllabus
								(id INT PRIMARY KEY AUTO_INCREMENT
								, cdept_id INT
								, syl_code CHAR(4) NOT NULL
								, syl_name VARCHAR(100) NOT NULL
								, CONSTRAINT fk_cdept_syllabus FOREIGN KEY (cdept_id) 
							     REFERENCES edu_cdept(cdept_id)
								);													
										
									
							
							
							
							
							
							
							
							
							
							
							
							
							