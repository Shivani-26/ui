SELECT col.col_code, col.col_name, col.city, col.state, col.year_opened, uni.univ_name, emp.name, dep.dept_name      
       FROM edu_college AS col 
       INNER JOIN edu_univ AS uni ON col.univ_code=uni.univ_code        
       INNER JOIN edu_cdept AS cdep ON col.id=cdep.college_id                                       
       INNER JOIN edu_dept AS dep ON cdep.udept_code=dep.dept_code 
       INNER JOIN edu_employee AS emp ON cdep.cdept_id =emp.cdept_id                                         
	    INNER JOIN edu_designation AS des ON emp.desig_id=des.id AND des.id=2 
	    WHERE dep.dept_name IN('cse','it');