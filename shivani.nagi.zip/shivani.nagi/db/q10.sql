SELECT stu.name, stu.id, stu.college_id, stu.cdept_id, stu.email, stu.phone, 
       stu.academic_year,
		 res.semester, res.grade, res.credits
       FROM edu_student AS stu
       INNER JOIN edu_semester_result AS res ON stu.id=res.stud_id AND res.credits>=8;
       
SELECT stu.name, stu.id, stu.college_id, stu.cdept_id, stu.email, stu.phone, 
       stu.academic_year,
		 res.semester, res.grade, res.credits
       FROM edu_student AS stu
       INNER JOIN edu_semester_result AS res ON stu.id=res.stud_id AND res.credits>=5;     