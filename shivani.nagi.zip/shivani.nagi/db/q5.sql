SELECT stu.id,  stu.name, stu.cdept_id, stu.roll_no,res.grade, res.credits, res.semester, 
       stu.academic_year, stu.phone, col.col_name, uni.univ_name
       FROM edu_semester_result AS res
       INNER JOIN edu_student AS stu ON stu.id=res.stud_id
		 INNER JOIN edu_college AS col ON stu.college_id=col.id
		 INNER JOIN edu_univ AS uni ON col.univ_code=uni.univ_code  
		 ORDER BY semester, col_name
		 LIMIT 10 OFFSET 10 ;              