package com.ofs.training;

import java.util.List;

public class AgeSorter {

    public List<Person> sortAge() {
        List<Person> roster = Person.createRoster();
        return roster.stream().sorted(List<Person>);
    }

    public static void main(String[] args) {
        AgeSorter sort = new AgeSorter();
        sort.sortAge();
    }
}
