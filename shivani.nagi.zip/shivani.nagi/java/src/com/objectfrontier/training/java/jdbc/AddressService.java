package com.objectfrontier.training.java.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;


public class AddressService {

    Address address;
    public Address create(Address address, Connection connection) throws Exception {
        if (address.getPostalCode() == null) {
            throw new RuntimeException("postal_code cannot be empty");
        }

        String query = "INSERT INTO address(street, city, postal_code) VALUES(?, ?, ?)";

        if (connection == null) {
            throw new RuntimeException("Service is not available");
        }

        PreparedStatement statement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
        statement.setString(1, address.getStreet());
        statement.setString(2, address.getCity());
        statement.setInt(3, address.getPostalCode());
        statement.executeUpdate();
        ResultSet result = statement.getGeneratedKeys();

        if (result.next()) {
            address.setId(result.getLong(1));
        }

        statement.close();
        return address;
    }

    public Address update(Address address, Connection connection) throws Exception {
        if (address.getId() == 0) {
            throw new RuntimeException("id cannot be zero");
        }

        String query = "UPDATE address SET street = ?, city = ?, postal_code = ? WHERE id = ?";

        if (connection == null) {
            throw new RuntimeException("Service is not available");
        }

        PreparedStatement stmt = connection.prepareStatement(query);
        stmt.setString(1, address.getStreet());
        stmt.setString(2, address.getCity());
        stmt.setInt(3, address.getPostalCode());
        stmt.setLong(4, address.getId());
        stmt.executeUpdate();

        stmt.close();
        return address;
    }

    public ArrayList<Address> readAll(Connection connection) throws Exception {
        ArrayList<Address> records = new ArrayList<>();
        String select = "SELECT id, street, city, postal_code FROM address";

        if (connection == null) {
            throw new RuntimeException("Service is not available");
        }

        PreparedStatement pstmt = connection.prepareStatement(select);
        ResultSet result = pstmt.executeQuery();

        while (result.next()) {
           Address address = new Address();
           address.setId(result.getInt("id"));
           address.setStreet(result.getString("street"));
           address.setCity(result.getString("city"));
           address.setPostalCode(result.getInt("postal_code"));
           records.add(address);
        }

        System.out.println(records);
        pstmt.close();
        return records;
    }

    public Address read(Address address, Connection connection) throws Exception {
        if (address.getId() == 0) {
            throw new RuntimeException("The entered parameter is invalid");
        }

        if (connection == null) {
            throw new RuntimeException("Service is not available");
        }

        String select = "SELECT id, street, city, postal_code FROM address WHERE id = ?";

        PreparedStatement pstmt = connection.prepareStatement(select);
        pstmt.setLong(1, address.getId());
        ResultSet result = pstmt.executeQuery();

        result.next();
        address.setId(result.getLong("id"));
        address.setStreet(result.getString("street"));
        address.setCity(result.getString("city"));
        address.setPostalCode(result.getInt("postal_code"));

        pstmt.close();
        return address;
    }

    public void delete(long id, Connection connection) throws Exception {
        if (id == 0) {
            throw new RuntimeException("The entered parameter is invalid");
        }

        if (connection == null) {
            throw new RuntimeException("Service is not available");
        }

        String delete = "DELETE FROM address WHERE id = ?";

        PreparedStatement statement = connection.prepareStatement(delete);
        statement.setLong(1, id);

        int resultSet = statement.executeUpdate();
        System.out.println("record sucessfully deleted " + resultSet);
        statement.close();
    }

    public static void main(String[] args) throws Exception {
        AddressService addressService = new AddressService();
        ConnectionManager connector = new ConnectionManager();
        Connection connection = connector.initConnection("jdbc:mysql://pc1620:3306/shivani_nagi?useSSL=false&user=shivani_nagi&password=demo");

        Address address = new Address();
        address.setStreet("reddiyar st");
        address.setCity("salem");
        address.setPostalCode(636204);

        System.out.println(addressService.create(address, connection));

        Address addressOne = new Address();
        addressOne.setStreet("gandhi nagar");
        addressOne.setCity("salem");
        addressOne.setPostalCode(235435);
        System.out.println(addressService.create(addressOne, connection));

        Address addressTwo = new Address();
        addressTwo.setStreet("ay nagar");
        addressTwo.setCity("salem");
        addressTwo.setPostalCode(230035);
        System.out.println(addressService.create(addressTwo, connection));

        Address actAddress = new Address();
        actAddress.setStreet("tharpaikadu");
        actAddress.setPostalCode(787456);
        actAddress.setId(2);
        actAddress.setCity("salem");
        System.out.println(addressService.update(actAddress, connection));

        addressService.readAll(connection);
        Address readAddress = new Address();
        readAddress.setId(2);
        System.out.println(addressService.read(readAddress, connection));

//        address.setId(1)
        addressService.delete(5, connection);
//        connection.close();
    }
}
