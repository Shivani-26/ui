package com.objectfrontier.training.java.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionManager {

    public Connection initConnection(String connectionString) {

        Connection conn = null;
        try {
        conn = DriverManager.getConnection(connectionString);
        conn.setAutoCommit(false);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conn;
    }
}
