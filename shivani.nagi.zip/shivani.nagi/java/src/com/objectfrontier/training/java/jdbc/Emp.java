package com.objectfrontier.training.java.jdbc;

public class Emp {

    public static void main(String[] args) {

//        int a = 1;
//        int b = 1;
//
//        System.out.println(a == b);
////        System.out.println(a.equals(b));
//
//        System.out.println(5 == 3);
//        System.out.println(5 == 5);

        String s1 = "a";
        String s2 = "a";
        String s3 = new String("a");
        String s4 = new String("a");

//        System.out.println(s1 == s2);
//        System.out.println(s1.equals(s2) );
//        System.out.println(s1 == s3);
        System.out.println(s1.equals(s3));
        System.out.println(s3 ==s4);
    }
}
