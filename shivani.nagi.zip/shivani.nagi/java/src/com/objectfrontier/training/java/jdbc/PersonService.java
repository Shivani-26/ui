package com.objectfrontier.training.java.jdbc;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import java.sql.PreparedStatement;

public class PersonService {

    AddressService addressService;

    public PersonService(AddressService addressService) {
        this.addressService = addressService;
    }

//    Address address;
    public Person create(Person person, Address address, Connection connection) throws Exception {

        if(person.getFirstname() == null) {
            throw new RuntimeException("firstname cannot be null");
        }
        if(person.getLastname() == null) {
            throw new RuntimeException("lastname cannot be null");
        }

        String query= "INSERT INTO person (firstname, lastname, email, birth_date, address_id) VALUES (?, ?, ?, ?, ?)";

        if (connection == null) {
            throw new RuntimeException("Service not found");
        }

        //        Address address = new Address();
        AddressService addressService = new AddressService();
        Address addressOne = addressService.create(address, connection);
        long addressId = addressOne.getId();

        PreparedStatement stmt = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
        stmt.setString(1, person.getFirstname());
        stmt.setString(2, person.getLastname());
        stmt.setString(3, person.getEmail());
        stmt.setDate(4, person.getBirthDate());
        stmt.setLong(5, addressId);
        stmt.executeUpdate();
        ResultSet result = stmt.getGeneratedKeys();

        if (result.next()) {
            person.setId(result.getLong(1));
        }

        return person;
    }
    public Person read(Person person, boolean includeAddress, Connection connection) throws Exception {
        if (person.getId() == 0) {
            throw new RuntimeException("Id cannot be empty");
        }

        String readQuery = "SELECT id, firstname, lastname, email, birth_date, address_id FROM person WHERE id = ?";

        if (connection == null) {
            throw new RuntimeException("Service is not available");
        }

        PreparedStatement preparedStatement = connection.prepareStatement(readQuery);
        preparedStatement.setLong(1, person.getId());
        ResultSet result = preparedStatement.executeQuery();

        result.next();
        person.setId(result.getLong("id"));
        person.setFirstname(result.getString("firstname"));
        person.setLastname(result.getString("lastname"));
        person.setEmail(result.getString("email"));
        person.setBirthDate(result.getDate("birth_date"));

        if(includeAddress) {
            //            System.out.println(person);
            Address addressReader = new Address();
            addressReader.setId(result.getLong("address_id"));

            AddressService addressService = new AddressService();

            Address readAddress = addressService.read(addressReader, connection);
            person.setAddress(readAddress);

        }
        //        System.out.println(person.address.getStreet());
        return person;
    }

    public ArrayList<Person> readAll(Connection connection) throws Exception {
        ArrayList<Person> list = new ArrayList<>();
        String readAllQuery = "SELECT id, firstname, lastname, email, birth_date, created_date, address_id FROM person";

        if (connection == null) {
            throw new RuntimeException("Service not found");
        }

        PreparedStatement preparedStatement = connection.prepareStatement(readAllQuery);
        ResultSet result = preparedStatement.executeQuery();

        while(result.next()) {
            Person person = new Person();
            person.setId(result.getLong("id"));
            person.setFirstname(result.getString("firstname"));
            person.setLastname(result.getString("lastname"));
            person.setEmail(result.getString("email"));
            person.setBirthDate(result.getDate("birth_date"));
            person.setCreatedDate(result.getDate("created_date"));

            Address address = new Address();
            address.setId(1);
            System.out.println(address);
            Address personAddress = new Address();
            personAddress = addressService.read(address, connection);
            System.out.println(personAddress);
//            address.setId(result.getLong("id"));
//            System.out.println(address);
//            person.setAddress(address);

//            long addressId = person.getAddress().getId();
//            System.out.println(addressId);
//            address.setId(addressId);

            person.setAddress(personAddress);
            list.add(person);
        }
        System.out.println(list);
        return list;
    }

    public Person update(Person person, Address address, Connection connection) throws Exception {
        if (person.getId() == 0) {
            throw new RuntimeException("Id cannot be empty");
        }

        String updateQuery = "UPDATE person SET firstname = ?, lastname = ?, email = ?, birth_date = ? WHERE id = ?" ;

        if (connection == null) {
            throw new RuntimeException("Service is not available");
        }


        PreparedStatement preparedStatement = connection.prepareStatement(updateQuery);
        preparedStatement.setString(1, person.getFirstname());
        preparedStatement.setString(2, person.getLastname());
        preparedStatement.setString(3, person.getEmail());
        preparedStatement.setDate(4, person.getBirthDate());
        preparedStatement.setLong(5,person.getId());
        preparedStatement.executeUpdate();

        AddressService addressService = new AddressService();
        address = addressService.update(address, connection);
        person.setAddress(address);
        return person;
    }

    public void delete(long id, Connection connection) throws Exception {
        if (id == 0) {
            throw new RuntimeException("The entered parameter is invalid");
        }

        if (connection == null) {
            throw new RuntimeException("Service is not available");
        }

        Person anotherPerson = new Person();
        anotherPerson.setId(id);
        anotherPerson = read(anotherPerson, true, connection);

        long addressId = anotherPerson.getAddress().getId();

        String deleteQuery = "DELETE FROM person WHERE id = ?";

        PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery);
        preparedStatement.setLong(1, anotherPerson.getId());
        int result = preparedStatement.executeUpdate();
        AddressService addressService = new AddressService();
        addressService.delete(addressId, connection);
        System.out.println("record sucessfully deleted " + result);
    }

    public static void main(String[] args) throws Exception {
        ConnectionManager connector = new ConnectionManager();
        Connection connection = connector.initConnection("jdbc:mysql://pc1620:3306/shivani_nagi?useSSL=false&user=shivani_nagi&password=demo");

        PersonService ps = new PersonService(null);
//        Person readPerson = new Person();
//        readPerson.setId(3);
//        System.out.println(ps.read(readPerson, true, connection));
        //        System.out.println(readPerson.toString());
        ps.readAll(connection);
//        Person person = new Person();

        ps.delete(3, connection);

        Person updatePerson = new Person();
        updatePerson.setId(2);
        updatePerson.setFirstname("nagi");
        updatePerson.setLastname("reddi");
        updatePerson.setEmail("nadi@gmail.com");
        updatePerson.setBirthDate(Date.valueOf("1964-06-28"));

        Address updateAddress = new Address();
        updateAddress.setStreet("C st");
        updateAddress.setCity("salem");
        updateAddress.setPostalCode(872376);
        updatePerson.setAddress(updateAddress);
        System.out.println(ps.update(updatePerson, updateAddress, connection));
    }
}
