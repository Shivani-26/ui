package com.objectfrontier.training.java.jdbc;

import java.sql.Connection;
import java.util.ArrayList;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Test
public class TestAddressService {

    AddressService service;
    Address address = new Address();
    ConnectionManager manager = new ConnectionManager();
    Connection connection = manager.initConnection("jdbc:mysql://pc1620:3306/shivani_nagi?useSSL=false&user=shivani_nagi&password=demo");

    @BeforeClass
    private void setUp() {
        service = new AddressService();
    }

    @Test(dataProvider = "testCreate_positiveDP")
    private void testCreate_positive(Address address, Address expectedAddress) {
        try {
            Address actualAddress = service.create(address, connection); 
            Assert.assertEquals(actualAddress.toString(), expectedAddress.toString());
            connection.commit();
        }
        catch(Exception e) {
            Assert.fail("Unexpected exception for given input"
                        + address.getStreet()
                        + ","
                        + address.getCity()
                        + ","
                        + address.getPostalCode()
                        +".Expected value is "
                        + expectedAddress 
                        + ".",
                        e);
        }
    }

    @DataProvider
    private Object[][] testCreate_positiveDP() {
        Address address = new Address();
        address.setId(1);
        address.setStreet("reddiyar st");
        address.setCity("salem");
        address.setPostalCode(636204);
        
        Address addressSetter = new Address();
        addressSetter.setId(1);
        addressSetter.setStreet("reddiyar st");
        addressSetter.setCity("salem");
        addressSetter.setPostalCode(636204);
        
        Address addressOne = new Address();
        addressOne.setId(2);
        addressOne.setStreet("gandhi nagar");
        addressOne.setCity("salem");
        addressOne.setPostalCode(235435);
        
        Address addressSetterOne = new Address();
        addressSetterOne.setId(2);
        addressSetterOne.setStreet("gandhi nagar");
        addressSetterOne.setCity("salem");
        addressSetterOne.setPostalCode(235435);

        Address addressTwo = new Address();
        addressTwo.setId(3);
        addressTwo.setStreet("A st");
        addressTwo.setCity("slm");
        addressTwo.setPostalCode(457576);

        Address addressSetterTwo = new Address();
        addressSetterTwo.setId(3);
        addressSetterTwo.setStreet("A st");
        addressSetterTwo.setCity("slm");
        addressSetterTwo.setPostalCode(457576);

        Address addressThree = new Address();
        addressThree.setId(4);
        addressThree.setStreet("C st");
        addressThree.setCity("bgl");
        addressThree.setPostalCode(789451);

        Address addressSetterThree = new Address();
        addressSetterThree.setId(4);
        addressSetterThree.setStreet("C st");
        addressSetterThree.setCity("bgl");
        addressSetterThree.setPostalCode(789451);

        return new Object[][] {
            {address, addressSetter},
            {addressOne, addressSetterOne},
            {addressTwo, addressSetterTwo},
            {addressThree, addressSetterThree}
        };
    }

    @Test(dataProvider = "testUpdate_positiveDP")
    private void testUpdate_positive(Address address, Address expectedAddress) {
        try {
             Address actualAddress = service.update(address, connection); 
            Assert.assertEquals(actualAddress.toString(), expectedAddress.toString());
            connection.commit();
        }
        catch(Exception e) {
            e.getMessage();
            Assert.fail("Unexpected exception for given input"
                        + address.getId()
                        + ","
                        + address.getStreet()
                        + ","
                        + address.getPostalCode()
                        +".Expected value is "
                        + expectedAddress 
                        + ".",
                        e);
        }
    }

    @DataProvider
    private Object[][] testUpdate_positiveDP() {
        Address actAddress = new Address();
        actAddress.setStreet("tharpaikadu st");
        actAddress.setPostalCode(787456);
        actAddress.setId(2);
        
        Address expectedAddress = new Address();
        expectedAddress.setStreet("tharpaikadu st");
        expectedAddress.setPostalCode(787456);
        expectedAddress.setId(2);

        return new Object[][] {
            {actAddress, expectedAddress}
        };
    } 

    @Test
    private void testUpdate_negative() {
        Address address = new Address();
        address.setStreet("");
        address.setPostalCode(545487);
        address.setId(1);
        try {
            service.update(address, null);
            Assert.fail("Expected an exception.");
            connection.commit();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "Service is not available");
        }
    }
    @Test
    private void testUpdate_negative1() {
        Address address = new Address();
        address.setStreet("");
        address.setPostalCode(658754);
        address.setId(0);
        try {
            service.update(address, connection);
            Assert.fail("Expected an exception.");
            connection.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "id cannot be zero");
        }
    }

    @Test(dataProvider = "testReadAll_positiveDP")
    private void testReadAll_positive(ArrayList<Address> expectedList) {
        try {
            ArrayList<Address> actualList = service.readAll(connection);
            Assert.assertEquals(actualList.toString(), expectedList.toString());
            connection.commit();
        }
        catch(Exception e) {
            Assert.fail("Unexpected exception forgiven input "
                        +".Expected value is "
                        + expectedList 
                        + ".",
                        e);
        }
    }

    @DataProvider
    private Object[][] testReadAll_positiveDP() throws Exception {
        ArrayList<Address> list = new ArrayList<>(); 
        Address addressOne = new Address();
        addressOne.setId(1);
        addressOne.setStreet("reddiyar st");
        addressOne.setCity("salem");
        addressOne.setPostalCode(636204);

        list.add(addressOne);

        Address addressTwo = new Address();
        addressTwo.setId(3);
        addressTwo.setStreet("A st");
        addressTwo.setCity("slm");
        addressTwo.setPostalCode(457576);

        list.add(addressTwo);

        Address addressThree = new Address();
        addressThree.setId(4);
        addressThree.setStreet("C st");
        addressThree.setCity("bgl");
        addressThree.setPostalCode(789451);

        list.add(addressThree);

        return new Object[][] {
            {list}
        };
    }
    @Test
    private void testReadAll_negative1() {
        try {
            service.readAll(null);
            Assert.fail("Expected an exception.");
            connection.commit();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "Service is not available");
        }
    }

    @Test(dataProvider = "testRead_positiveDP")
    private void testRead_positive(Address address, Address expectedValue) {
        try {
            Address actualValue = service.read(address, connection);
            Assert.assertEquals(actualValue.toString(), expectedValue.toString());
            connection.commit();
        }
        catch(Exception e) {
            Assert.fail("Unexpected exception forgiven input "
                        +".Expected value is "
                        + expectedValue 
                        + ".",
                        e);
        }
    }
    @DataProvider
    private Object[][] testRead_positiveDP() {
        Address readAddress = new Address();
        readAddress.setId(1);
        Address expectedResult = new Address();
        expectedResult.setId(1);
        expectedResult.setStreet("A st");
        expectedResult.setCity("slm");
        expectedResult.setPostalCode(457576);
        return new Object[][] {
            {readAddress, expectedResult}
        };
    }
    @Test
    private void testRead_negative1() {
        try {
            service.read(address, null);
            Assert.fail("Expected an exception.");
            connection.commit();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "The entered parameter is invalid");
        }
    }
    @Test(dataProvider = "testDelete_positiveDP")
    private void testDelete_positive(long id) {
        try {
            service.delete(id, connection);
            connection.commit();
        }
        catch(Exception e) {
            Assert.fail("Unexpected exception for given input "
                        +".Expected value is "
                        + address.getId()
                        + ".",
                        e);
        }
    }

    @DataProvider
    private Object[][] testDelete_positiveDP() {
        return new Object[][] {
            {2}
        };
    }
    @Test
    private void testDelete_negative1() {
        try {
            service.delete(0, connection);
            Assert.fail("Expected an exception.");
            connection.commit();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "The entered parameter is invalid");
        }
    }
    @Test
    private void testDelete_negative2() {
        try {
            service.delete(1, null);
            Assert.fail("Expected an exception.");
            connection.commit();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "Service is not available");
        }
    }

    @AfterClass
    private void Teardown() throws Exception {
        service = null;
        connection.close();
    }
}
