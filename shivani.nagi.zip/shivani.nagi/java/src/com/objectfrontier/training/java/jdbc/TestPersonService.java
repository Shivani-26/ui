package com.objectfrontier.training.java.jdbc;

import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestPersonService {

    Person person;
    PersonService service;
    ConnectionManager manager = new ConnectionManager();
    Connection connection = manager.initConnection("jdbc:mysql://pc1620:3306/shivani_nagi?useSSL=false&user=shivani_nagi&password=demo");

    @BeforeClass
    private void initClass() {
        service = new PersonService(null);
    }

    @Test(dataProvider = "testCreate_positiveDP")
    private void testCreate_positive(Person person,Address address, Person expectedResult) {
        try {
            Person actualResult = service.create(person, address, connection);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
            connection.commit();
        } catch (Exception e) {
            Assert.fail("unexpected exception " + person.getFirstname()
                                                + person.getLastname()
                                                + person.getEmail()
                                                + person.getBirthDate()
                                                + person.getAddress().getId()
                                                + "Expected result is "
                                                + expectedResult
                                                + ". ",
                                               e);
        }
    }
    @DataProvider
    private Object[][] testCreate_positiveDP() {
        Person personSetter = new Person();
        personSetter.setId(1);
        personSetter.setFirstname("shiv");
        personSetter.setLastname("ani");
        personSetter.setEmail("shiv@gmail.com");
        personSetter.setBirthDate(Date.valueOf("1996-05-26"));

        Address address = new Address();
        address.setStreet("A st");
        address.setCity("slm");
        address.setPostalCode(457576);
        personSetter.setAddress(address);

        Person expectedPerson = new Person();
        expectedPerson.setId(1);
        expectedPerson.setFirstname("shiv");
        expectedPerson.setLastname("ani");
        expectedPerson.setEmail("shiv@gmail.com");
        expectedPerson.setBirthDate(Date.valueOf("1996-05-26"));
        expectedPerson.setAddress(address);

        Person personSetterOne = new Person();
        personSetterOne.setId(2);
        personSetterOne.setFirstname("ruchi");
        personSetterOne.setLastname("ra");
        personSetterOne.setEmail("ruchi@gmail.com");
        personSetterOne.setBirthDate(Date.valueOf("2000-12-23"));

        Address addressOne = new Address();
        addressOne.setStreet("B st");
        addressOne.setCity("cbe");
        addressOne.setPostalCode(546568);
        personSetterOne.setAddress(addressOne);

        Person expectedPersonOne = new Person();
        expectedPersonOne.setId(2);
        expectedPersonOne.setFirstname("ruchi");
        expectedPersonOne.setLastname("ra");
        expectedPersonOne.setEmail("ruchi@gmail.com");
        expectedPersonOne.setBirthDate(Date.valueOf("2000-12-23"));
        expectedPersonOne.setAddress(addressOne);

        Person personSetterTwo = new Person();
        personSetterTwo.setId(3);
        personSetterTwo.setFirstname("selva");
        personSetterTwo.setLastname("rani");
        personSetterTwo.setEmail("rani@gmail.com");
        personSetterTwo.setBirthDate(Date.valueOf("1974-12-07"));

        Address addressTwo = new Address();
        addressTwo.setStreet("A st");
        addressTwo.setCity("slm");
        addressTwo.setPostalCode(457576);
        personSetterTwo.setAddress(addressTwo);

        Person expectedPersonTwo = new Person();
        expectedPersonTwo.setId(3);
        expectedPersonTwo.setFirstname("selva");
        expectedPersonTwo.setLastname("rani");
        expectedPersonTwo.setEmail("rani@gmail.com");
        expectedPersonTwo.setBirthDate(Date.valueOf("1974-12-07"));
        expectedPersonTwo.setAddress(addressTwo);

        return new Object[][] {
            {personSetter, address, expectedPerson},
            {personSetterOne, addressOne, expectedPersonOne},
            {personSetterTwo, addressTwo, expectedPersonTwo}
        };
    }

    @Test
    private void testCreate_negative1() throws Exception {

        try {
            Person personSetter = new Person();
            personSetter.setFirstname(null);
            personSetter.setLastname("ani");
            personSetter.setEmail("shiv@gmail.com");
            personSetter.setBirthDate(Date.valueOf("1996-05-26"));
            
            Address address = new Address();
            address.setStreet("A st");
            address.setCity("slm");
            address.setPostalCode(457576);

            service.create(person, address, connection);
            Assert.fail("Expected an exception");
            connection.commit();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "firstname cannot be null");
            e.getMessage();
            connection.rollback();
        }
    }

    @Test(dataProvider = "testRead_positiveDP")
    private void testRead_positive(Person person, boolean includeAddress, Person expectedResult) {
        try {
            Person actualResult = service.read(person, includeAddress, connection);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
            connection.commit();
        } catch (Exception e) {
            Assert.fail("unexpected exception "
                        + person
                        + "Expected result is "
                        + expectedResult
                        + ".",
                        e);
        }
    }

    @DataProvider
    private Object[][] testRead_positiveDP() {
        Person personReader = new Person();
        personReader.setId(3);

        Person ExpectedPersonReader = new Person();
        ExpectedPersonReader.setId(3);
        ExpectedPersonReader.setFirstname("selva");
        ExpectedPersonReader.setLastname("rani");
        ExpectedPersonReader.setEmail("rani@gmail.com");
        ExpectedPersonReader.setBirthDate(Date.valueOf("1974-12-07"));

        Address address = new Address();
        address.setId(3);
        address.setStreet("A st");
        address.setCity("slm");
        address.setPostalCode(457576);

        ExpectedPersonReader.setAddress(address);
        return new Object[][] {
            {personReader, true, ExpectedPersonReader}
        };
    }

    @Test
    private void testRead_negative() {
        Person personReader = new Person();
        personReader.setId(0);
        try {
            service.read(personReader, true, connection);
            Assert.fail("Expected an Exception");
            connection.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "Id cannot be empty");
        }
    }

    @Test(dataProvider = "testUpdate_positiveDP")
    private void testupdateCheck_positive1(Person person, Address address, Person expectedResult) throws SQLException {

        try {
            Person actualResult = service.update(person, address, connection);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
            connection.commit();
        } catch (Exception e) {
            Assert.fail(new StringBuilder()
                    .append("Unexpected exception for input ")
                    .append(person.getFirstname())
                    .append(" , ")
                    .append(person.getLastname())
                    .append(" , ")
                    .append(person.getEmail())
                    .append(" , ")
                    .append(person.getBirthDate())
                    .append(" , ")
                    .append(person.getId())
                    .append(" , ")
                    .append("Expected result is ")
                    .append(expectedResult).toString());
            connection.rollback();
        }
    }

    @DataProvider
    private Object[][] testUpdate_positiveDP() {

        Person person = new Person();

        person.setId(1);
        person.setFirstname("jothi");
        person.setLastname("jaya");
        person.setEmail("jothi@gmail.com");
        person.setBirthDate(Date.valueOf("1958-09-03"));

        Address address = new Address();
        address.setId(1);
        address.setStreet("reddi street");
        address.setCity("salem");
        address.setPostalCode(636204);

        Person expectedPerson = new Person();
        expectedPerson.setId(1);
        expectedPerson.setFirstname("jothi");
        expectedPerson.setLastname("jaya");
        expectedPerson.setEmail("jothi@gmail.com");
        expectedPerson.setBirthDate(Date.valueOf("1958-09-03"));
        expectedPerson.setAddress(address);


        return new Object[][] {
            { person, address, expectedPerson}
        };
    }


    @Test
    private void testUpdateCheck_negative1() {
        Person person  = new Person();
        person.setId(0);
        person.setEmail("shiv@gmail.com");
        person.setFirstname("shiv");
        person.setLastname("ani");
        person.setBirthDate(Date.valueOf("1978-12-21"));
        Address address = new Address();
        address.setStreet("reddiyar street");
        address.setCity("salem");
        address.setPostalCode(654545);

        try {
            service.update(person, address, connection);;
            Assert.fail("Expected an exception.");
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "Id cannot be empty") ;
        }
    }

    @Test
    private void testUpdateCheck_negative2() {

        Person person  = new Person();
        person.setId(1);
        person.setEmail("");
        person.setFirstname("");
        person.setLastname("");
        person.setBirthDate(Date.valueOf("1978-12-21"));
        
        Address address = new Address();
        address.setStreet("reddiyar street");
        address.setCity("salem");
        address.setPostalCode(654545);
        try {

            service.update(person, address, null);;
            Assert.fail("Expected an exception.");
        } catch (Exception e) {
                Assert.assertEquals(e.getMessage(), "Service is not available") ;
            }
        
        }

    @Test(dataProvider = "testReadAll_positiveDP")
    private void testReadAll_positiveDP(ArrayList<Person> expectedResult) {
        try {
            ArrayList<Person> actualResult = service.readAll(connection);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
            connection.commit();
        } catch (Exception e) {
            Assert.fail("unexpected exception"
                        + "Expected result is"
                        + expectedResult
                        + ".",
                        e);
        }
    }
    @DataProvider
    private Object[][] testReadAll_positiveDP() throws Exception {

        ArrayList<Person> list = new ArrayList<>();
        Person personSetter = new Person();
        personSetter.setId(1);
        personSetter.setFirstname("jothi");
        personSetter.setLastname("jaya");
        personSetter.setEmail("jothi@gmail.com");
        personSetter.setBirthDate(Date.valueOf("1958-09-26"));

        Address address = new Address();
        address.setId(1);
        address.setStreet("reddiyar st");
        address.setCity("salem");
        address.setPostalCode(636204);
        personSetter.setAddress(address);

        list.add(personSetter);

//        Person personSetterOne = new Person();
//        personSetterOne.setId(2);
//        personSetterOne.setFirstname("ruchi");
//        personSetterOne.setLastname("ra");
//        personSetterOne.setEmail("ruchi@gmail.com");
//        personSetterOne.setBirthDate(Date.valueOf("2000-12-23"));
//
//        Address addressOne = new Address();
//        addressOne.setStreet("B st");
//        addressOne.setCity("cbe");
//        addressOne.setPostalCode(546568);
//        personSetterOne.setAddress(addressOne);
//
//        list.add(personSetterOne);

        Person personSetterTwo = new Person();
        personSetterTwo.setId(3);
        personSetterTwo.setFirstname("selva");
        personSetterTwo.setLastname("rani");
        personSetterTwo.setEmail("rani@gmail.com");
        personSetterTwo.setBirthDate(Date.valueOf("1974-12-07"));

        Address addressTwo = new Address();
        address.setId(2);
        addressTwo.setStreet("A st");
        addressTwo.setCity("slm");
        addressTwo.setPostalCode(457576);
        personSetterTwo.setAddress(addressTwo);

        list.add(personSetterTwo);
        return new Object[][] {
            {list}
        };
    }

    @Test
    private void testReadAll_negative() {
        try {
            service.readAll(null);
            Assert.fail("Expected an Exception");
            connection.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "record_not_found");
        }
    }
    @Test(dataProvider = "testDelete_positiveDP")
    private void testDelete_positive(long id) throws Exception {
        try {
            service.delete(id, connection);
            connection.commit();
        }
        catch(Exception e) {
//            e.getMessage();
            Assert.fail("Unexpected exception for given input "
                        +".Expected value is "
                        + person.getId()
                        + ".",
                        e);
            connection.rollback();
        }
    }

    @DataProvider
    private Object[][] testDelete_positiveDP() {
        return new Object[][] {
            {2}
        };
    }
    @Test
    private void testDelete_negative1() throws Exception {

        try {
            service.delete(0, connection);
            Assert.fail("Expected an exception.");
            connection.commit();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "The entered parameter is invalid");
            connection.rollback();
        }
    }
    @Test
    private void testDelete_negative2() throws Exception {
        Person person = new Person();
        person.setId(1);
        try {
            service.delete(1, null);
            Assert.fail("Expected an exception.");
            connection.commit();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "Service is not available");
            connection.rollback();
        }
    }

    @AfterClass
    private void Teardown() throws Exception {
        service = null;
        connection.close();
    }
}

