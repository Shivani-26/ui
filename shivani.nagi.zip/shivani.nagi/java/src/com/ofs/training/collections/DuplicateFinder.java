package com.ofs.training.collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class DuplicateFinder {

    public List<Integer> findDup(List<Integer> randomNumbers) {
        return randomNumbers.stream().distinct().collect(Collectors.toList());
    }

    public static void main(String[] args) {
        List<Integer> randomNumbers = new ArrayList<>();
        randomNumbers.addAll(Arrays.asList(1, 6, 10, 1, 25, 78, 10, 25));
//        Integer one = new Integer(1);
        randomNumbers.add(new Integer(1));
//        List<Person> roster = Person.createRoster();
//        Person bob2 = new Person("Bob", IsoChronology.INSTANCE.date(2000, 9, 12),
//                                                   Person.Sex.MALE,
//                                                   "bob@example.com");
//        roster.add(bob2);
//        List<Person> person = roster.stream().distinct().collect(Collectors.toList());
//        System.out.println(person);
        DuplicateFinder dup = new DuplicateFinder();
        System.out.println(5 == 5);
        List<Integer> findDup = dup.findDup(randomNumbers);
        System.out.println(findDup);
    }
}
