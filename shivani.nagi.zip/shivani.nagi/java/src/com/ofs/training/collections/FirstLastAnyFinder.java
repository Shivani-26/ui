package com.ofs.training.collections;

import java.util.List;

public class FirstLastAnyFinder {

    public String findfirst(List<Person> roster) {
        return roster.stream().findFirst().get().toString();
    }

    public String findAny(List<Person> roster) {
        return roster.stream().findAny().get().toString();
    }

    public String findLast(List<Person> roster) {
        long count = roster.stream().count();
        return roster.stream().skip(count -1).findFirst().get().toString();
    }

    public static void main(String[] args) {
        List<Person> roster = Person.createRoster();
        FirstLastAnyFinder finder = new FirstLastAnyFinder();

        String first = finder.findfirst(roster);
        String any = finder.findAny(roster);
        String last = finder.findLast(roster);
        System.out.println(first);
        System.out.println(last);
        System.out.println(any);
    }
}
