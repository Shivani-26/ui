package com.ofs.training.collections;

import java.util.Iterator;
import java.util.List;

public class ListIterator {

    public List<Person> printIterator(List<Person> roster) {
        Iterator<Person> iterator = roster.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }
        return roster;
    }
    public static void main(String[] args) {
        List<Person> person = Person.createRoster();
        ListIterator itr = new ListIterator();
        itr.printIterator(person);
    }
}
