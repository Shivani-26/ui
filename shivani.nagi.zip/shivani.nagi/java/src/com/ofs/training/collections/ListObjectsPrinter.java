package com.ofs.training.collections;

import java.util.List;


public class ListObjectsPrinter {

    public void printObject() {
        List<Person> roster = Person.createRoster();
        roster.stream().forEach(person -> { System.out.println(person); });
    }

    public static void main(String[] args) {
        ListObjectsPrinter printer = new ListObjectsPrinter();
        printer.printObject();
    }
}
