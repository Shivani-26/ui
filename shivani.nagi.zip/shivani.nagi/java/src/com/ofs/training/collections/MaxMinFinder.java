package com.ofs.training.collections;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class MaxMinFinder {

    List<Integer> randomNumbers = Arrays.asList(1, 6, 10, 25, 78);

    public static void main(String[] args) {

        MaxMinFinder finder = new MaxMinFinder();
        int min = finder.randomNumbers.stream().
                                       min(Comparator.comparing(Integer :: valueOf)).
                                       get();
        int max = finder.randomNumbers.stream().
                                       max(Comparator.comparing(Integer :: valueOf)).
                                       get();
        int sum = finder.randomNumbers.stream().
                                       mapToInt(Integer :: valueOf).
                                       sum();
        System.out.println(min);
        System.out.println(max);
        System.out.println(sum);
    }
}
