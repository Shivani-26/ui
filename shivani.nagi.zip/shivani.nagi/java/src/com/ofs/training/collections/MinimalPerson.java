package com.ofs.training.collections;

import java.util.List;
import java.util.stream.Collectors;

public class MinimalPerson {

    public List<String> toMinimalPerson() {
        List<Person> roster = Person.createRoster();

        return roster.stream().map(person -> person.emailAddress).
//                               map(pers -> pers.name).
                               collect(Collectors.toList());
    }

    public static void main(String[] args) {
        MinimalPerson mini = new MinimalPerson();
        System.out.println(mini.toMinimalPerson());
    }
}
