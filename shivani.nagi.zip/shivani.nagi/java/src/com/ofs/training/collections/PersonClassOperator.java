package com.ofs.training.collections;

import java.time.chrono.IsoChronology;
import java.util.ArrayList;
import java.util.List;

public class PersonClassOperator {

    public List<Person> addPerson() {
        List<Person> roster = Person.createRoster();
        List<Person> newRoster = new ArrayList<>();
        newRoster.add(new Person("John", IsoChronology.INSTANCE.date(1980, 6, 20),
                                         Person.Sex.MALE,
                                         "john@example.com"));
        newRoster.add(new Person("Jade", IsoChronology.INSTANCE.date(1990, 7, 15),
                                         Person.Sex.FEMALE,
                                         "jade@example.com"));
        newRoster.add(new Person("Donald", IsoChronology.
                                           INSTANCE.date(1991, 8, 13),
                                           Person.Sex.MALE,
                                           "donald@example.com"));
        Person bob = new Person("Bob", IsoChronology.INSTANCE.date(2000, 9, 12),
                                        Person.Sex.MALE,
                                        "bob@example.com");
//        roster.addAll(newRoster);
        System.out.format("%s%n", roster);
        System.out.println(roster.size());
//        System.out.println(newRoster.remove(bob));

        Person bob2 = new Person("Bob", IsoChronology.INSTANCE.date(2000, 9, 12),
                                                   Person.Sex.MALE,
                                                   "bob@example.com");
//        System.out.println(roster.add(bob2));
//        System.out.println(roster.size());
//
//        System.out.println(roster.retainAll(newRoster));
//        System.out.println(roster);
//        System.out.println(roster.size());
//
//        System.out.println(newRoster.contains(bob));

//        System.out.println(roster.removeAll(roster));
        System.out.format("is bob removed : %s ", roster.remove(bob2));

        return roster;
    }

    public static void main(String[] args) {
        PersonClassOperator person = new PersonClassOperator();
        person.addPerson();
    }
}
