package com.ofs.training.collections;

import java.util.List;
import java.util.stream.Collectors;

public class PersonFilter {

    public List<Person> filter(List<Person> roster) {

        return roster.stream().
                      filter(person -> { return person.getAge() > 21; }).
                      filter(person -> { return person.getGender() == Person.Sex.MALE; }).
                      collect(Collectors.toList());
    }
    public static void main(String[] args) {

        List<Person> roster = Person.createRoster();
        PersonFilter person = new PersonFilter();
        List<Person> filter = person.filter(roster);
        System.out.println(filter);
    }
}
