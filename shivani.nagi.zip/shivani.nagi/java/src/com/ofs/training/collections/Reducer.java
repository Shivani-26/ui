package com.ofs.training.collections;

import java.util.List;

public class Reducer {

    public int getAvgAge(List<Person> roster) {
        return roster.stream().
                      map(Person :: getAge).
                      reduce(0, (a, b) -> (a + b)/2);
}
    public long getAverageAge(List<Person> roster) {
        return roster.stream().
                      map(Person :: getAge).
                      reduce(0, (a, b) -> (a + b)/2);
    }

    public static void main(String[] args) {

        List<Person> roster = Person.createRoster();
        Reducer reduce = new Reducer();
        long averageAge = reduce.getAverageAge(roster);
        System.out.println(averageAge);
        int avgAge = reduce.getAvgAge(roster);
        System.out.println(avgAge);
    }
}
