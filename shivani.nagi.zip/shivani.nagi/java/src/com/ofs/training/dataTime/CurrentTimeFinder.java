package com.ofs.training.dataTime;

import java.lang.System;
import java.time.Clock;
import java.time.Instant;

public class CurrentTimeFinder {

    public void printTime() {
//        long currentTime = System.currentTimeMillis();
//        System.out.println(currentTime);

//        Instant currentTime = Instant.now();

        Clock clock = Clock.systemUTC();
        Instant currentTime = clock.instant();
        System.out.println(currentTime);
    }

    public static void main(String[] args) {
        CurrentTimeFinder finder = new CurrentTimeFinder();
        finder.printTime();
    }
}
