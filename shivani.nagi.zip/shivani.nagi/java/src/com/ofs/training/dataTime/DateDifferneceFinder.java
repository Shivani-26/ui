package com.ofs.training.dataTime;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateDifferneceFinder {
    private void findDifference() throws Exception {
        SimpleDateFormat format = new SimpleDateFormat("dd MM yyyy");
        String inputString1 = "23 04 1997";
        String inputString2 = "27 04 1997";

        Date date1 = format.parse(inputString1);
        Date date2 = format.parse(inputString2);
        long diff = date2.getTime() - date1.getTime();
        
        System.out.println(diff / 1000 / 60 / 60 / 24);
    }
    public static void main(String[] args) throws Exception {
        DateDifferneceFinder finder = new DateDifferneceFinder();
        finder.findDifference();
    }
}
