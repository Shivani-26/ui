//2. Formatting current date to following formats: 2001-07-04T12:08:56.235-0700 and 2001.07.04 at 12:08:56 PDT
package com.ofs.training.dataTime;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateFormatter {

    public static void main(String[] args) {
        Date currentDate = new Date();
        System.out.println(currentDate);

        String datePatternOne = "yyyy-MM-dd'T'HH:mm:ss.z";
        String datePatternTwo = "yyyy.MM.dd 'at' HH:mm:ss z";

        SimpleDateFormat dateFormater = new SimpleDateFormat(datePatternOne);
        String firstDate = dateFormater.format(currentDate);
        System.out.println(firstDate);
        SimpleDateFormat dateFormaterTwo = new SimpleDateFormat(datePatternTwo);
        String secondDate = dateFormaterTwo.format(currentDate);
        System.out.println(secondDate);
    }
}
