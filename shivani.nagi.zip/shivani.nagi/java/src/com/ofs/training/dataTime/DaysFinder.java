//4. For a given year, print the length of each month within that year.

package com.ofs.training.dataTime;

import java.time.Year;

public class DaysFinder {

    public void printDayOfMonth() {
        Year year = Year.of(2016);

        for (int month = 1; month <= 12; month++) {
            System.out.println(year.atMonth(month).lengthOfMonth());
        }
    }

    public static void main(String[] args) {
        DaysFinder demo = new DaysFinder();
        demo.printDayOfMonth();
    }
}
