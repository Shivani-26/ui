package com.ofs.training.dataTime;

public class EpochTime {
    public void findEpoch() {
        long epochTime = System.currentTimeMillis();
        System.out.println(epochTime);
    }
    public static void main(String[] args) {
        EpochTime finder = new EpochTime();
        finder.findEpoch();
    }

}
