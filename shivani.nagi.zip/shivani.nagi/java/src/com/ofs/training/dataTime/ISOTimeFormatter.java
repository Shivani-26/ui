package com.ofs.training.dataTime;

import java.time.LocalDate;

public class ISOTimeFormatter {
    private void printISODate() {
    LocalDate date = LocalDate.now();
    System.out.println(date);
    }
    public static void main(String[] args) {
        ISOTimeFormatter formatter = new ISOTimeFormatter();
        formatter.printISODate();
        
    }
}
