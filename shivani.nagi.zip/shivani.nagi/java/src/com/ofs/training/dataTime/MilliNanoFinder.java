package com.ofs.training.dataTime;

public class MilliNanoFinder {
    public void finderTime(){
        long milliSecTime = System.currentTimeMillis();
        System.out.println(milliSecTime);
        long nanoSecTime = System.nanoTime();
        System.out.println(nanoSecTime);
    }
    public static void main(String[] args) {
        MilliNanoFinder finder = new MilliNanoFinder();
        finder.finderTime();
    }
}
