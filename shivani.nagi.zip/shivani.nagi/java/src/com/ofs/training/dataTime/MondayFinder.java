package com.ofs.training.dataTime;

import java.time.DayOfWeek;
import java.time.Month;
import java.time.Year;
import java.time.YearMonth;
import java.util.Calendar;

public class MondayFinder {

    public void findMonday(Month monthOne) {
        Year year = Year.now();
        System.out.println(year);
        YearMonth month = year.atMonth(monthOne);
        System.out.println(month);
//        DayOfWeek monday = month.atDay(dayOfMonth);

        Calendar cal = Calendar.getInstance();
        int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
        System.out.println(dayOfMonth);
    }
    public static void main(String[] args) {
        MondayFinder finder = new MondayFinder();
        finder.findMonday(Month.APRIL);
    }
}
