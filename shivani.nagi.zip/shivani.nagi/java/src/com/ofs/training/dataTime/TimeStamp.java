package com.ofs.training.dataTime;

import java.sql.Timestamp;

public class TimeStamp {

    private void findTimeStamp() {
        long time = System.currentTimeMillis();
        Timestamp timeStamp = new Timestamp(time);
        System.out.println(timeStamp);
    }
    public static void main(String[] args) {
        TimeStamp timer = new TimeStamp();
        timer.findTimeStamp();
    }
}
