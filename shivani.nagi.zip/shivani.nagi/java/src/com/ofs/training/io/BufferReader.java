package com.ofs.training.io;

import java.io.BufferedReader;
import java.io.FileReader;

public class BufferReader {
        public void printFromFile(String path) throws Exception {
        BufferedReader br =new BufferedReader(new FileReader(path));
        System.out.println(br.readLine());
        String line = null;
        while ((line = br.readLine()) != null) {
            System.out.println(line);
        }
        br.close();
    }
        public static void main(String[] args) throws Exception {
            BufferReader reader = new BufferReader();
            reader.printFromFile("D:/temp/wbs.txt");
        }
}
