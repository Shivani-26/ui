package com.ofs.training.io;

import java.io.File;
import java.io.FileReader;

public class FileDataReader {

    public static void main(String[] args) throws Exception {
        File file = new File(args[0]);
        FileReader inputStream = new FileReader(file);

        char[] cbuf = new char[1036];
        int data = inputStream.read(cbuf);

        System.out.println(data);
        System.out.println(cbuf);
        inputStream.close();
    }
}
