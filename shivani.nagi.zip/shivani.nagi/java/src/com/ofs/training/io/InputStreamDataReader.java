package com.ofs.training.io;

import java.io.InputStream;

public class InputStreamDataReader {

    public void printInputStreamDataReader() throws Exception {
//        File file = new File("D:/temp/wbs.txt");
//        InputStream inputStream = new FileInputStream(file);
        InputStream inputStream = this.getClass().getResourceAsStream("BufferReader.class");

        byte[] buffer = new byte[inputStream.available()];
        inputStream.read(buffer);

        for (byte buf : buffer) {
            System.out.print((char)buf);
        }
        inputStream.close();
    }

    public static void main(String[] args) throws Exception {
        InputStreamDataReader reader = new InputStreamDataReader();
        reader.printInputStreamDataReader();
    }
}
