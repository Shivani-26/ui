package com.ofs.training.io;

import java.io.FileOutputStream;

public class OutputStreamStringWriter {

    public void writeString(String phrase) throws Exception {

        FileOutputStream file = new FileOutputStream("D:/temp/String.txt");
        byte[] bite = phrase.getBytes();
        file.write(bite, 0, phrase.length());
        System.out.println();
        for (byte eachByte : bite) {
            System.out.print((char)eachByte);
        }
    }
    public static void main(String[] args) throws Exception {
        OutputStreamStringWriter writer = new OutputStreamStringWriter();
        writer.writeString("I work in ofs");
    }
}
