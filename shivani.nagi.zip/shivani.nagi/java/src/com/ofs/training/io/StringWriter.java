package com.ofs.training.io;

import java.io.File;
import java.io.FileWriter;

public class StringWriter {

    public void writeString(String phrase) throws Exception {

        File file = new File("D:/temp/String1.txt");
        FileWriter writer = new FileWriter(file);
        writer.write(phrase);
        System.out.println(file);
        writer.close();
    }
    public static void main(String[] args) throws Exception {
        StringWriter writer = new StringWriter();
        writer.writeString("I work in object frontier software");
    }
}
