package com.ofs.training.java;

import java.io.File;

// class AbsolutePath
public class AbsolutePath {

    // static void execute()
    public static void main(String[] args) {

        File file = new File("AbsolutePath.class");
        String fpath = file.getAbsolutePath();
        System.out.println("Absolute path is : " + fpath);
    }
}
