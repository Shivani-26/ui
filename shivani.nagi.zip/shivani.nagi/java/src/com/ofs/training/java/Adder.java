package com.ofs.training.java;

public class Adder {

    private static int add(int... values) {
        int sum = 0;

        for (int number : values) {
            sum += number;
        }
        System.out.println(sum);
        return sum;
    }

    public static void main(String[] args) {
        add(5, 6, 7);
        add(5, 6, 7, 8, 9);
    }
}
