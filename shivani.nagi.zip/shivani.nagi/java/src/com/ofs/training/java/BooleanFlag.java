package com.ofs.training.java;

public class BooleanFlag {

    boolean check(int number) {

        if (number > 3) {
            return true;
        }
        return false;
    }
    public static void main(String[] args) {
        BooleanFlag flag = new BooleanFlag();
        System.out.println(flag.check(4));
        System.out.println(flag.check (2));
        System.out.println(flag.check (3));
        System.out.println(flag.check (7));
    }
}
