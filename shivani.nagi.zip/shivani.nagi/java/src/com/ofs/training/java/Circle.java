package com.ofs.training.java;

public class Circle extends Shape {

    private int radius;
    static final float PI = 3.14f;

    Circle(int radius) {
        this.radius = radius;
    }

    public float area() {
        return PI * radius * radius;
    }

    public float perimeter() {
        return 2 * PI * radius;
    }

    public static void main(String[] args) {
        Shape circle = new Circle(5);
        System.out.println(circle.area());
        System.out.println(circle.perimeter());
    }
}
