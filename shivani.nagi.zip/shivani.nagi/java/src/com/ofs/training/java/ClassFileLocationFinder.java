package com.ofs.training.java;

// class ClassFileLocationFinder
public class ClassFileLocationFinder {

    // static void execute()
    public static void main(String[] args) {

        // class currentProgram = getCurrentPogram()
        // class currentClass = getClass()
        ClassFileLocationFinder currentProgram = new ClassFileLocationFinder();
        Class<?> currentClass = currentProgram.getClass();

        // File currentClassFile = currentClass.getFile()
        // String absPath = currentClassFile.getAbsPath()
        String absolutePath = currentClass.getProtectionDomain()
                                          .getCodeSource()
                                          .getLocation()
                                          .getFile();

        // Console console = getConsole()
        // console.print(absolutePath)
        System.out.println(absolutePath + currentProgram.getClass() + ".class");
    }
}
