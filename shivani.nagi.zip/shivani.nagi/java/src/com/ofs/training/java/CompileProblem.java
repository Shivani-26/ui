package com.ofs.training.java;

public class CompileProblem {
    static String s;

    public static void main(String[] args) {
        CompileProblem.Inner in = new CompileProblem.Inner();
        in.testMethod();
    }

    static class Inner {

        void testMethod() {

            //OuterClass.StaticNestedClass nestedObject =new OuterClass.StaticNestedClass();
            //CompileProblem.Inner inn = new CompileProblem.Inner();
            System.out.println(s = "Set from Inner");
        }
    }
}