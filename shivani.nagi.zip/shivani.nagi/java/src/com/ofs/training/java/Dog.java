package com.ofs.training.java;

public class Dog extends Animal {

    int tail;
    public void bark(int count) {
        
        if (count < 10 ) {
            System.out.println("No stranger entering indication");
        } else if (count > 10) {
            System.out.println("Indication of stranger");
        }
    }

    public void see(int eyes) {
        System.out.println("The dog sees");
    }

    public static void main(String[] args) {
        Animal animal = new Animal();
        animal.legs = 2;
        animal.run(5);
        Dog puppy = new Dog ();
        puppy.bark(7);
        puppy.see(5);
        Animal jacky = new Dog();
        jacky.legs = 4;
        jacky.run(4);
    }
}
