package com.ofs.training.java;

public class Employee {

	static int id;
	String name;
	
	Employee(String empName) {
		
		id++;
		name = empName;
	}
	
	public static void main(String[] args) {

		Employee emp1 = new Employee("Abi");
		System.out.println(emp1.name + Employee.id);
		Employee emp2 = new Employee("Ays");
		System.out.println(emp2.name + Employee.id);
		Employee emp3 = new Employee("nandhu");
		System.out.println(emp3.name + Employee.id);
		Employee emp4 = new Employee("sara");
		System.out.println(emp4.name + Employee.id);
		Employee emp5 = new Employee("Shivani");
		System.out.println(emp5.name + Employee.id);
	}
}
