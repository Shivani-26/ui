package com.ofs.training.java;

import java.util.Scanner;

// class FibonacciUsingFor
public class FibonacciUsingFor {

    private static Scanner scan;

	// static void execute()
    public static void main(String[] args) {
        int firstNumber = 0, secondNumber = 1, result;
        scan = new Scanner(System.in);

        // Console console = getConsole()
        // console.print(getInput)
        System.out.println("enter number of terms");
        int terms = scan.nextInt();

        // Console console = getConsole()
        // console.print(beginning values of the series)
        System.out.println("The fibonicci series is :" + firstNumber + secondNumber);

        // generateSeries(n)
        for (int index = 2; index <= terms; index++) {
            result = firstNumber + secondNumber;

            // Console console = getConsole()
            // console.print(nextValue)
            System.out.print(" " + result);
            firstNumber = secondNumber;
            secondNumber = result;
        }
    }
}
