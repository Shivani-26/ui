package com.ofs.training.java;

import java.util.Scanner;

// class FibonacciUsingWhile
public class FibonacciUsingWhile {

    private static Scanner scan;

	// static void execute()
    public static void main(String[] args) {

        int numberOne = 0, numberTwo = 1, numberThree;
        scan = new Scanner(System.in);
        System.out.println("enter integer");
        int n = scan.nextInt();

        // Console console = getConsole()
        // console.print(beginning values of the series)
        System.out.print("The fibonicci series is :" + numberOne);

        int index = 0;
		while (index <= n) {
            numberThree = numberOne + numberTwo;
            System.out.print(" " + numberThree);
            numberOne = numberTwo;
            numberTwo = numberThree;
            index++;
        }
    }
}
