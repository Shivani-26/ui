package com.ofs.training.java;

public class FloatPointAdder {

    static float add(float...numbers) {

        float sum = 0;
        for (float number : numbers) {
            sum += number;
        }
        return sum;
    }

    public static void main(String[] args) {
        System.out.println(add(8.5f, 0.6f, 3.7f));
        System.out.println(add(5.1f, 6.1f, 7.4f, 8.2f ,9.9f));
    }
}
