package com.ofs.training.java;

import java.util.Scanner;

public class InitialFinder {

    public static String getInitial(String name) {

        if (name == null) {
            throw new RuntimeException("Name is invalid");
        }

        String surName = name.substring(name.lastIndexOf(' ') + 1);
        String initial = surName.substring(0, 1);
        return initial;
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter the name to compute initial :");

        String name = in.nextLine();
        String initial = getInitial(name);
        System.out.println(initial);
    }
}
