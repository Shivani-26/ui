package com.ofs.training.java;

import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;

public class InitialFinderTest {

	private static final String String = null;
	InitialFinder initialfinder;

	@BeforeClass
	private void initClass() {
		initialfinder = new InitialFinder();
	}

	@Test(dataProvider = "testPrintInitial_validNameDP")
	private void testPrintInitial_validName(String name, String expectedValue) {

		try {
			String actualValue = initialfinder.getInitial(name);
			Assert.assertEquals(actualValue, expectedValue, "Given input" + name);
		} catch (Exception e) {
			Assert.fail("Unexpected exception for input"
					    + name
					    + ". Expected result is"
					    + expectedValue);
		}
	}

	@DataProvider
	private Object[][] testPrintInitial_validNameDP() {
		return new Object[][] {
			{"Shiv Ruchi", "SR"},
			{"Rani", "R"},
			{"Lakshmi", "L"},
			{"Jaya Jothi", "JJ"}
		};
	}

	private void testPrintInitial_NullName() {
		try {
			initialfinder.getInitial("Null");
			Assert.fail("Expected an exception.");
		} catch (Exception e) {
			Assert.assertEquals(e.getMessage(), "Initial cannot be found with a null value");
		}
	}

	@AfterClass
	private void afterClass () {

	}
}
