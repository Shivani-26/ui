package com.ofs.training.java;

public class Math {

    private static final String ERR_DIVIDE_BY_ZERO = "can't divide by 0";

    public int divide(int dividend, int divisor) {
        if (divisor == 0) {
            throw new RuntimeException(ERR_DIVIDE_BY_ZERO);
        }
        return (dividend/divisor);
    }
}
