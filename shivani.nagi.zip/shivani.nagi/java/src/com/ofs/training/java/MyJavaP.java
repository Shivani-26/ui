package com.ofs.training.java;

public class MyJavaP {
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        String packageName = args[0];

        if (args.length != 1) {
            System.out.println("The arguments passed must not exceed one");
            return;
        }
        String[] className = packageName.split("\\.");
    }

}
