package com.ofs.training.java;

//import java.util.Scanner;

public class Number {

//    private static Scanner scan;
	static int aNumber = 4;

//	 static void execute()
    public static void main(String[] args) {

//        scan = new Scanner(System.in);
//        System.out.println("enter integer");
//        int aNumber = scan.nextInt();

        if (aNumber >= 3) {
            if (aNumber == 3) {
            System.out.println("first string");
            } else {
                System.out.println("second string");
                System.out.println("third string");
            }
        }
    }
}
