package com.ofs.training.java;


public class NumberContainer {

    public int anInt;
    public float aFloat;

    public static void main(String[] args) {

        NumberContainer num = new NumberContainer();
        System.out.println(num.anInt = 4);
        System.out.println(num.aFloat = 4);
    }
}
