package com.ofs.training.java;

// class NumberHolder
public class NumberHolder {
    public int anInt;
    public float aFloat;

    // static void execute()
    public static void main(String[] args) {

        NumberHolder number = new NumberHolder();
        number.anInt = 4;
        number.aFloat = 0.4f;

        // Console console = getConsole()
        // console.print(print first string)
        System.out.println(number.anInt);
        System.out.println(number.aFloat);
    }
}