package com.ofs.training.java;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.ofs.training.java.ObjectEqualityWithEnum.ComputerHardware;

public class ObjectEqualityUsingEnumTest {

	//test methods
	//non-test methods

	ObjectEqualityWithEnum obj;

	@BeforeClass
	private void initClass() {
		obj = new ObjectEqualityWithEnum();
	}

	@Test(dataProvider = "testEnumEquality1_validObjectDP")
	private void testEnumEquality1_positive1(ComputerHardware partOne,ComputerHardware partTwo, boolean expectedValue) {

		try {
			boolean actualValue = obj.enumEquality1(partOne, partTwo);
			Assert.assertEquals(actualValue, expectedValue, "Given input" + partOne + partTwo);
		} catch (Exception e) {
			Assert.fail("Unexpected exception for input"
					+ partOne
					+" , "
					+ partTwo
					+ ". Expected result is"
					+ expectedValue);
		}
	}

	@DataProvider
	private Object[][] testEnumEquality1_validObjectDP() {
		return new Object[][] {
			{ComputerHardware.CPU, ComputerHardware.MONITOR, false },
			{ComputerHardware.CPU, ComputerHardware.CPU, true},
			{ComputerHardware.MOUSE, ComputerHardware.MONITOR, false },
			{ComputerHardware.MONITOR, ComputerHardware.MONITOR, true }
		};
	}

	@Test(dataProvider = "testEnumEquality2_validObjectDP")
	private void testEnumEquality2_positive2(ComputerHardware partOne,ComputerHardware partTwo, boolean expectedValue) {

		try {
			boolean actualValue = obj.enumEquality2(partOne, partTwo);
			Assert.assertEquals(actualValue, expectedValue, "Given input" + partOne + partTwo);
		} catch (Exception e) {
			Assert.fail("Unexpected exception for input"
					+ partOne
					+" , "
					+ partTwo
					+ ". Expected result is"
					+ expectedValue);
		}
	}

	@DataProvider
	private Object[][] testEnumEquality2_validObjectDP() {
		return new Object[][] {
			{ComputerHardware.CPU, ComputerHardware.MONITOR, false },
			{ComputerHardware.CPU, ComputerHardware.CPU, true},
		};
	}

	@Test
	private void testEnumEquality1_negative() {
		try {
			obj.enumEquality1(null, ComputerHardware.CPU);
			Assert.fail("Expected an exception.");
		} catch (Exception e) {
			Assert.assertEquals(e.getMessage(), "This is not an object of enum");
		}
	}

	@AfterClass
	private void afterClass () {

	}
}