package com.ofs.training.java;

// class ObjectEquality
public class ObjectEqualityWithEnum {

	private static final String ERR_IF_NOT_IN_ENUM = "This is not an object of enum";

	// enum ComputerHardware
	enum ComputerHardware {
		MONITOR,
		CPU,
		KEYBOARD,
		MOUSE;
	}

	public boolean enumEquality1(ComputerHardware hardware1, ComputerHardware hardware2) {    	

		try {
			boolean value = hardware1.equals(hardware2);
			return value;
		} catch (Exception e) {
			throw new RuntimeException(ERR_IF_NOT_IN_ENUM);
		}	
	}

	public boolean enumEquality2(ComputerHardware hardware1, ComputerHardware hardware2) {
		try {
			if (hardware1 == hardware2) {
				return true;
			} else {
				return false;
			} 
		} catch (Exception e) {
			throw new RuntimeException(ERR_IF_NOT_IN_ENUM);
		}
	}

	public static void main(String[] args) {

		ObjectEqualityWithEnum equality = new ObjectEqualityWithEnum();
		ComputerHardware hardware1 = ComputerHardware.MONITOR;
		ComputerHardware hardware2 = ComputerHardware.CPU;
		System.out.println(equality.enumEquality1(hardware1, hardware2));
		System.out.println(equality.enumEquality2(hardware1, hardware2));

	}
}
