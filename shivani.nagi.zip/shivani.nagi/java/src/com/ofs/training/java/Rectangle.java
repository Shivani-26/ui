package com.ofs.training.java;

public class Rectangle {

    int width;
    int height;
    int area() {
        int rectArea = width * height;
        return rectArea;
    };

    public static void main(String[] args) {
        Rectangle myRect = new Rectangle();
        myRect.width = 4;
        myRect.height = 5;
        System.out.println("myRect's width is " + myRect.width);
    }
}
