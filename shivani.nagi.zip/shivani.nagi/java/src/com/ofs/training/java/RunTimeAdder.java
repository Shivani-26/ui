package com.ofs.training.java;

public class RunTimeAdder {

    public static void main(String[] args) {

        if (!(args.length < 2)) {
            int sum = 0;

            for (int index = 0; index < args.length; index++) {
                sum += Integer.parseInt(args[index]);
            }
            System.out.println(sum);
        } else {
            System.out.println(" the arguments cannot be less than 2");
        }
    }
}
