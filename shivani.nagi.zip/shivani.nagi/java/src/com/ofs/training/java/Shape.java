package com.ofs.training.java;

public abstract class Shape {

    public abstract float area();
    public abstract float perimeter();
}
