package com.ofs.training.java;

import java.util.Arrays;
public class SortArray {

    public static void main(String[] args) {

        String[] cities = { "Madurai", 
                            "Thanjavur", 
                            "TRICHY", 
                            "Karur", 
                            "Erode", 
                            "trichy", 
                            "Salem" };

        System.out.println("this is the sorted array : ");
        Arrays.sort(cities);
        System.out.println(cities);
        for (int index = 0; index < cities.length; index++) {
            if (index % 2 == 0) {
                System.out.println(cities[index].toUpperCase());
            } else {
                System.out.println(cities[index]);
            }
        }
    }
}
