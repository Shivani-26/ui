package com.ofs.training.java;

public class Square extends Shape {

    private int side;

    Square(int side) {
        this.side = side;
    }

    public float area() {
        return 2 * side;
    }

    public float perimeter() {
        return 4 * side;
    }

    public static void main(String[] args) {
        Shape square = new Square(7);
        System.out.println(square.area());
        System.out.println(square.perimeter());
    }
}
