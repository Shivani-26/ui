package com.ofs.training.java;

public class StringBackward implements CharSequence {

    private String name;
    char[] nameCharacters;

    StringBackward(String name) {
        this.name = name;
    }

    @Override
    public int length() {
        nameCharacters = name.toCharArray();
        int count = 0;

        for (char ch : nameCharacters) {
            count++;
        }
        charAt(count);
        return count;
    }

    @Override
    public char charAt(int index) {

        nameCharacters = name.toCharArray();
        for (int i = 0; i < index; i++) {
            System.out.print(nameCharacters[i]);
        }
        System.out.println();
        subSequence(0, index - 1);
        return 0;
    }

    @Override
    public CharSequence subSequence(int start, int end) {
        nameCharacters = name.toCharArray();
        char[] ch = new char[10];

        for (int i = start; i < end; i++) {
            ch[i] = nameCharacters[i];
            System.out.print(ch[i]);
        }
        System.out.println();
        CharSequence sequence = new String(ch);
        toString();
        return null;
    }

    @Override
    public String toString() {
        StringBuffer name = new StringBuffer("object");
        return name.reverse().toString();
    }

    public static void main(String[] args) {

        StringBackward inter = new StringBackward("object");
        System.out.println(inter.length());
    }

}
