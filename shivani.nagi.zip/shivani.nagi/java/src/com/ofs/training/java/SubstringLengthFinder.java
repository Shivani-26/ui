package com.ofs.training.java;

public class SubstringLengthFinder {

    private static final String ERR_NOT_STRING = "The given value is not a String";
    String given;

    public String convert(String given) {
        try {
            String sub = given.substring(9, 12);
            System.out.println("The substring is : " + sub);
            System.out.println("The length of the substring is : " + sub.length());
            return sub;
        } catch (Exception e) {
            throw new RuntimeException(ERR_NOT_STRING);
        }
    }

    public static void main(String[] args) {
        SubstringLengthFinder finder = new SubstringLengthFinder();
        finder.convert("My nativ is Salem ");
        finder.convert("Was it a car or a cat I saw?");
    }
}
