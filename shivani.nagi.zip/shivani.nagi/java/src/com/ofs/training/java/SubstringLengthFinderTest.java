package com.ofs.training.java;

import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;

@Test
public class SubstringLengthFinderTest {
    // test methods
    // non-test methods
    SubstringLengthFinder substring;

    @BeforeClass
    private void initClass() {
        substring = new SubstringLengthFinder();
    }

    @Test (dataProvider = "testConvert_validStringDP")
    private void testConvert_validString1(String given, String expectedValue) {
        try {
            String actualValue = substring.convert(given);
            Assert.assertEquals(actualValue, expectedValue, "Given input" + given);
        } catch (Exception e) {
            Assert.fail("Unexpected exception for input "
                        + given
                        + ". Expected result is "
                        + expectedValue
                        + ".",
                        e);
        }
    }

    @DataProvider
    private Object[][] testConvert_validStringDP() {
        return new Object[][] {
            {"Was it a car or a cat I saw?", "car"},
            {"My nativ is Salem ", "is "}
        };
    }

    private void testConvert_invalidString() {
        try {
            substring.convert(null);
            Assert.fail("Expected an exception.");
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "The given value is not a String");
        }
    }

    @AfterClass
    private void afterClass() {
    }

}
