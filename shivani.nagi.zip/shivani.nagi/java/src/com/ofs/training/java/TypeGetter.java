package com.ofs.training.java;

public class TypeGetter {

    public static void main(String[] args) {
        // TODO Auto-generated method stub

        Object divOne = 100 / 24;
        System.out.println(divOne.getClass().getTypeName());

        Object divTwo = 100.10 / 10;
        System.out.println(divTwo.getClass().getTypeName());

        Object divThree = 'Z' / 2;
        System.out.println(divThree.getClass().getTypeName());

        Object divFour = 10.5 / 0.5;
        System.out.println(divFour.getClass().getTypeName());

        Object divFive = 12.4 % 5.5;
        System.out.println(divFive.getClass().getTypeName());

        Object divSix = 100 % 56;
        System.out.println(divSix.getClass().getTypeName());

    }
}
