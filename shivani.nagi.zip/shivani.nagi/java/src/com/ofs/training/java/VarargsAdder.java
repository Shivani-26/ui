package com.ofs.training.java;

public class VarargsAdder {

    static int add(int... number) {
    	
        System.out.format("Number of arguments : %d " + number.length);
        System.out.println("The sum is");
        int sum = 0;
        for (int x : number) {
        	sum += x;
        }
        return sum;
    }

    public static void main(String[] args) {
        System.out.println(add(5, 6, 7));
        System.out.println(add(5, 6, 7, 8 ,9));
    }
}
