package com.ofs.training.java;

public class WrapperClassDemo {

    private void overloadWrapper(Integer value) {
        System.out.println("it is an integer" + value);
    }

    private void overloadWrapper(Float value) {
        System.out.println(value);
    }

    private void overloadWrapper(int value) {
        System.out.println(value);
    }

    private void overloadWrapper(Long value) {
        System.out.println(value);
    }

    private void overloadWrapper(Double value) {
        System.out.println(value);
    }

    public static void main(String[] args) {

        WrapperClassDemo wrap = new WrapperClassDemo();
        Integer wrap2 = new Integer(0);
        wrap.overloadWrapper(wrap2);
        wrap.overloadWrapper(4);
        wrap.overloadWrapper(1.0f);
        wrap.overloadWrapper(234523l);
        wrap.overloadWrapper(24.35);
    }
}
