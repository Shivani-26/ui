package com.ofs.training.math;

import java.math.BigDecimal;
import java.math.MathContext;

public class BigDecimalOperator {
    private void findRoundOff() {
        BigDecimal value = new BigDecimal(46.24352345);
        System.out.println("round ceiling value is " + value.setScale(3, BigDecimal.ROUND_CEILING));
        System.out.println("round floor value is " + value.setScale(3, BigDecimal.ROUND_FLOOR));
        MathContext mc = new MathContext(4);
        System.out.println("round off precision value is" + value.round(mc));
    }
    private void findAbsolute() {
        BigDecimal value = new BigDecimal(46.24352345);
        System.out.println("abs value is " + value.abs());
        }
    private void findMaxMin() {
        BigDecimal value = new BigDecimal(46.24352345);
        BigDecimal val = new BigDecimal(23.45646232);
        System.out.println("max value is " + value.max(val));
        System.out.println("min value is " + value.min(val));
    }
    public static void main(String[] args) {
        BigDecimalOperator rounder = new BigDecimalOperator();
        rounder.findRoundOff();
        rounder.findAbsolute();
        rounder.findMaxMin();
    }
}
