package com.ofs.training.service;

import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Test
public class AddressServiceTest {

    AddressService service;
    Address address = new Address();
    ConnectionManager manager = new ConnectionManager();
    Connection connection = manager.initConnection();

    @BeforeClass
    private void setUp() {
        service = new AddressService();
    }

    @Test(dataProvider = "testCreate_positiveDP")
    private void testCreate_positive(Address address, Address expectedAddress) {
        try {
            Address actualAddress = service.create(address, connection); 
            Assert.assertEquals(actualAddress.toString(), expectedAddress.toString());
            connection.commit();
        }
        catch(Exception e) {
            Assert.fail("Unexpected exception for given input"
                        +address.getId()
                        +","
                        + address.getStreet()
                        + ","
                        + address.getCity()
                        + ","
                        + address.getPostalCode()
                        +".Expected value is "
                        + expectedAddress 
                        + ".",
                        e);
        }
    }

    @DataProvider
    private Object[][] testCreate_positiveDP() {
        Address address = new Address();
        address.setId(1);
        address.setStreet("reddiyar st");
        address.setCity("salem");
        address.setPostalCode(636204);
        
        Address addressSetter = new Address();
        addressSetter.setId(1);
        addressSetter.setStreet("reddiyar st");
        addressSetter.setCity("salem");
        addressSetter.setPostalCode(636204);
        
        Address addressOne = new Address();
        addressOne.setId(2);
        addressOne.setStreet("gandhi nagar");
        addressOne.setCity("salem");
        addressOne.setPostalCode(235435);
        
        Address addressSetterOne = new Address();
        addressSetterOne.setId(2);
        addressSetterOne.setStreet("gandhi nagar");
        addressSetterOne.setCity("salem");
        addressSetterOne.setPostalCode(235435);

        Address addressTwo = new Address();
        addressTwo.setId(3);
        addressTwo.setStreet("A st");
        addressTwo.setCity("slm");
        addressTwo.setPostalCode(457576);

        Address addressSetterTwo = new Address();
        addressSetterTwo.setId(3);
        addressSetterTwo.setStreet("A st");
        addressSetterTwo.setCity("slm");
        addressSetterTwo.setPostalCode(457576);

        Address addressThree = new Address();
        addressThree.setId(4);
        addressThree.setStreet("C st");
        addressThree.setCity("bgl");
        addressThree.setPostalCode(789451);

        Address addressSetterThree = new Address();
        addressSetterThree.setId(4);
        addressSetterThree.setStreet("C st");
        addressSetterThree.setCity("bgl");
        addressSetterThree.setPostalCode(789451);

        return new Object[][] {
            {address, addressSetter},
            {addressOne, addressSetterOne},
            {addressTwo, addressSetterTwo},
            {addressThree, addressSetterThree}
        };
    }

    @Test(dataProvider = "testCreate_negative_DP")
    private void testCreate_negative1(Address address, AppException expected) throws Exception {

        try {
            service.read(address, connection);
            Assert.fail("Expected an exception.");
            connection.commit();
        } catch (AppException e) {
            Assert.assertEquals(e.getMessage(), expected.getMessage());
            connection.rollback();
        }
    }

    @DataProvider
    private Object[][] testCreate_negative_DP() {

        Address address = new Address();
        address.setId(0);
        address.setStreet("A st");
        address.setCity("slm");
        address.setPostalCode(457576);

        ArrayList<Error> errors = new ArrayList<>();
        errors.add(Error.INVALID_ADDRESS_ID);

        Address addressFour = new Address();
        address.setId(1);
        addressFour.setStreet(null);
        addressFour.setCity("slm");
        addressFour.setPostalCode(457576);

        ArrayList<Error> errorFour = new ArrayList<>();
        errorFour.add(Error.INVALID_STREET);

        Address addressFive = new Address();
        address.setId(1);
        addressFive.setStreet("A st");
        addressFive.setCity(null);
        addressFive.setPostalCode(457576);

        ArrayList<Error> errorFive = new ArrayList<>();
        errorFive.add(Error.INVALID_CITY);

        Address addressSix = new Address();
        address.setId(1);
        addressSix.setStreet("A st");
        addressSix.setCity("slm");
        addressSix.setPostalCode(null);

        ArrayList<Error> errorSix = new ArrayList<>();
        errorSix.add(Error.INVALID_POSTAL_CODE);

        return new Object[][] {
            {address, new AppException(errors)},
            {addressFour, new AppException(errorFour)},
            {addressFive, new AppException(errorFive)},
            {addressSix, new AppException(errorSix)}
        };
    }

    @Test(dataProvider = "testUpdate_positiveDP")
    private void testUpdate_positive(Address address, Address expectedAddress) {
        try {
             Address actualAddress = service.update(address, connection); 
            Assert.assertEquals(actualAddress.toString(), expectedAddress.toString());
            connection.commit();
        }
        catch(Exception e) {
            e.getMessage();
            Assert.fail(
                    "Unexpected exception for given input"
                        + address.getStreet()
                        + ","
                        +address.getCity()
                        + ","
                        + address.getPostalCode()
                        +","
                        + address.getId()
                        +".Expected value is "
                        + expectedAddress 
                        + ".",
                        e);
        }
    }

    @DataProvider
    private Object[][] testUpdate_positiveDP() {
        Address actAddress = new Address();
        actAddress.setStreet("tharpaikadu st");
        actAddress.setCity("salem");
        actAddress.setPostalCode(787456);
        actAddress.setId(2);

        return new Object[][] {
            {actAddress, actAddress}
        };
    } 

    @Test(dataProvider = "testUpdate_negative_DP")
    private void testUpdate_negative(Address address, AppException expected) throws Exception {

        try {
            service.update(address, connection);
            Assert.fail("Expected an exception.");
            connection.commit();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), expected.getMessage());
            connection.rollback();
        }
    }
    @DataProvider
    private Object[][] testUpdate_negative_DP() {

        Address address = new Address();
        address.setId(0);
        address.setStreet("A st");
        address.setCity("slm");
        address.setPostalCode(457576);

        ArrayList<Error> errors = new ArrayList<>();
        errors.add(Error.INVALID_ADDRESS_ID);

        Address addressFour = new Address();
        address.setId(1);
        addressFour.setStreet(null);
        addressFour.setCity("slm");
        addressFour.setPostalCode(457576);

        ArrayList<Error> errorFour = new ArrayList<>();
        errorFour.add(Error.INVALID_STREET);

        Address addressFive = new Address();
        address.setId(1);
        addressFive.setStreet("A st");
        addressFive.setCity(null);
        addressFive.setPostalCode(457576);

        ArrayList<Error> errorFive = new ArrayList<>();
        errorFive.add(Error.INVALID_CITY);

        Address addressSix = new Address();
        address.setId(1);
        addressSix.setStreet("A st");
        addressSix.setCity("slm");
        addressSix.setPostalCode(null);

        ArrayList<Error> errorSix = new ArrayList<>();
        errorSix.add(Error.INVALID_POSTAL_CODE);

        return new Object[][] {
            {address, new AppException(errors)},
            {addressFour, new AppException(errorFour)},
            {addressFive, new AppException(errorFive)},
            {addressSix, new AppException(errorSix)}
        };
    }

    @Test(dataProvider = "testReadAll_positiveDP")
    private void testReadAll_positive(ArrayList<Address> expectedList) {
        try {
            ArrayList<Address> actualList = service.readAll(connection);
            Assert.assertEquals(actualList.toString(), expectedList.toString());
            connection.commit();
        }
        catch(Exception e) {
            Assert.fail
                       ("Expected value is "
                        + expectedList 
                        + ".",
                        e);
//                    ("Unexpected exception for given input"
//                        + address.getId()
//                        +","
//                        + address.getStreet()
//                        + ","
//                        +address.getCity()
//                        + ","
//                        + address.getPostalCode()
//                        +".Expected value is "
//                        + expectedList 
//                        + ".",
//                        e);
        }
    }

    @DataProvider
    private Object[][] testReadAll_positiveDP() throws Exception {
        ArrayList<Address> List = new ArrayList<>(); 
        Address addressOne = new Address();
        addressOne.setId(1);
        addressOne.setStreet("reddiyar st");
        addressOne.setCity("salem");
        addressOne.setPostalCode(636204);
        
        List.add(addressOne);

//        Address addressFour = new Address();
//        addressFour.setId(2);
//        addressFour.setStreet("tharpaikadu st");
//        addressFour.setCity("salem");
//        addressFour.setPostalCode(787456);
//
//        List.add(addressFour);

        Address addressTwo = new Address();
        addressTwo.setId(3);
        addressTwo.setStreet("A st");
        addressTwo.setCity("slm");
        addressTwo.setPostalCode(457576);

        List.add(addressTwo);

        Address addressThree = new Address();
        addressThree.setId(4);
        addressThree.setStreet("C st");
        addressThree.setCity("bgl");
        addressThree.setPostalCode(789451);

        List.add(addressThree);

        return new Object[][] {
            {List}
        };
    }

    @Test(dataProvider = "testRead_positiveDP")
    private void testRead_positive(Address address, Address expectedValue) {
        try {
            Address actualValue = service.read(address, connection);
            Assert.assertEquals(actualValue.toString(), expectedValue.toString());
            connection.commit();
        }
        catch(Exception e) {
            Assert.fail("Unexpected exception for given input "
                        +address.getId()
                        +".Expected value is "
                        + expectedValue 
                        + ".",
                        e);
        }
    }
    @DataProvider
    private Object[][] testRead_positiveDP() {
        Address readAddress = new Address();
        readAddress.setId(1);

        Address expectedResult = new Address();
        expectedResult.setId(1);
        expectedResult.setStreet("reddiyar st");
        expectedResult.setCity("salem");
        expectedResult.setPostalCode(636204);
        return new Object[][] {
            {readAddress, expectedResult}
        };
    }
    @Test
    private void testRead_negative() throws Exception {
        Address address = new Address();
        address.setId(0);
        try {
            service.read(address, connection);
            Assert.fail("Expected an exception.");
            connection.commit();
        } catch (AppException e) {
            Assert.assertEquals(e.getMessage(), Error.INVALID_ADDRESS_ID);
        }
    }
    @Test(dataProvider = "testDelete_positiveDP")
    private void testDelete_positive(Address address) throws Exception {
        
        try {
            service.delete(address, connection);
            connection.commit();
        }
        catch(Exception e) {
            Assert.fail("Unexpected exception for given input "
                        +".Expected value is "
                        + address
                        + ".",
                        e);
            connection.rollback();
        }
    }

    @DataProvider
    private Object[][] testDelete_positiveDP() {
        Address address = new Address();
        address.setId(2);
        return new Object[][] {
            {address}
        };
    }

    @Test
    private void testDelete_negative() throws Exception {
        try {
            Address address = new Address();
            address.setId(0);
            service.delete(address, connection);
            Assert.fail("Expected an exception.");
            connection.commit();
        } catch (AppException e) {
            Assert.assertEquals(e.getMessage(), Error.INVALID_ADDRESS_ID);
        }
    }

    @AfterClass
    private void Teardown() throws Exception {
        service = null;
        connection.close();
    }
}

