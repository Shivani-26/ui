var addressInfoPanel = {};
addressInfoPanel.view;

addressInfoPanel.createChildren = function () {
}

addressInfoPanel.createView = function () {

    var request = new XMLHttpRequest();
    var READY_STATE_CODE = 4;
    var STATUS_CODE = 200;

    request.onreadystatechange = function() {
        if (this.readyState === READY_STATE_CODE && this.status === STATUS_CODE) {
                document.getElementById('app').innerHTML += this.responseText;
        }
    };

    request.open('GET', 'addressInfoPanel.html', false);
    request.send();
}

addressInfoPanel.prepopulate = function () {
    displayAddressDetails();
}

addressInfoPanel.listenEvents = function () {
    onClickReset();
    onClickSubmit();
}

addressInfoPanel.setDefault = function () {
    onSelectAddressFirstRecord();
}

addressInfoPanel.onInit = function () {
    addressInfoPanel.createChildren();
    addressInfoPanel.createView();
    addressInfoPanel.prepopulate();
    addressInfoPanel.listenEvents();
    addressInfoPanel.setDefault();
}