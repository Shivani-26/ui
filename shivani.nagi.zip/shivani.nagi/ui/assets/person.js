function getPerson() {
    var httpRequest = new XMLHttpRequest();
    httpRequest.onreadystatechange = function() {
        var responseReady = 4;
        var success = 200;
        if (this.readyState === responseReady && this.status === success) {
            document.getElementById("submit").innerHTML = this.responseText;
        }
    };
    httpRequest.open("GET", "person.json", true);
    httpRequest.send();
}