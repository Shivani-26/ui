function generateTable() {
    var httpRequest = new XMLHttpRequest();
    var responseReady = 4;
    var success = 200;

    httpRequest.open("GET", "personDisplay.json", true);
    httpRequest.send();

    httpRequest.onreadystatechange = function() {
        if (this.readyState === responseReady && this.status === success) {
                // document.getElementById("topDivision").innerHTML = this.responseText;
                var parsedPerson = JSON.parse(this.responseText);
                var col = [];
                for (var i = 0; i < parsedPerson.length; i++) {
                    for (var key in parsedPerson[i]) {
                        if (col.indexOf(key) === -1) {
                            col.push(key);
                        }
                    }
                }

                // CREATE DYNAMIC TABLE.
                var table = document.createElement("table");

                //Add the header row.
                var row = table.insertRow(-1);
                for (var i = 0; i < col.length; i++) {
                    var headerCell = document.createElement("th");
                    headerCell.innerHTML = col[i];
                    row.appendChild(headerCell);
                }
                //Add the data rows.
                for (var i = 0; i < parsedPerson.length; i++) {
                    row = table.insertRow(-1);
                    for (var j = 0; j < col.length; j++) {
                        var cell = row.insertCell(-1);
                        cell.innerHTML = parsedPerson[i][col[j]];
                    }
                }
                // FINALLY ADD THE NEWLY CREATED TABLE WITH JSON DATA TO A CONTAINER.
                var divContainer = document.getElementById("topDivision");
                divContainer.innerHTML = "";
                divContainer.appendChild(table);
            }
    };
}
function generatePersonDetail() {
    document.getElementById("bottomDivision").style.display = "block";
}
function submitRow() {
    var table = document.getElementById("table");
    var row = table.insertRow(table.length);

    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    var cell3 = row.insertCell(2);
    var cell4 = row.insertCell(3);
    var cell5 = row.insertCell(4);

    var id = document.getElementById("id").value;
    var firstName = document.getElementById("firstName").value;
    var lastName = document.getElementById("lastName").value;
    var birthDate = document.getElementById("birthDate").value;
    var email = document.getElementById("email").value;
   
    cell1.innerHTML = id;
    cell2.innerHTML = firstName;
    cell3.innerHTML = lastName;
    cell4.innerHTML = birthDate;
    cell5.innerHTML = email;

    var divContainer = document.getElementById("topDivision");
    divContainer.innerHTML = "";
    divContainer.appendChild(table);
}
function resetToBlank() {
    document.getElementById('id').value = '';
    document.getElementById('firstName').value = '';
    document.getElementById('lastName').value = '';
    document.getElementById('birthDate').value = '';
    document.getElementById('email').value = '';
}
function selectRow() {
    var table = document.getElementById("table");
    for ( var i = 1; i < table.rows.length; i++) {
        table.rows[i].onclick = function () {
            document.getElementById("id").value = this.cells[0].innerHTML;
            document.getElementById("firstName").value = this.cells[1].innerHTML;
            document.getElementById("lastName").value = this.cells[2].innerHTML;
            document.getElementById("birthDate").value = this.cells[3].innerHTML;
            document.getElementById("email").value = this.cells[4].innerHTML;
        };
    }
}



