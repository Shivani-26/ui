function generateTable() {
    var httpRequest = new XMLHttpRequest();
    var responseReady = 4;
    var success = 200;

    httpRequest.open("GET", "personDisplay.json", true);
    httpRequest.send();

    httpRequest.onreadystatechange = function() {
        if (this.readyState === responseReady && this.status === success) {
                // document.getElementById("topDivision").innerHTML = this.responseText;
                var parsedPerson = JSON.parse(this.responseText);
                var col = [];
                for (var i = 0; i < parsedPerson.length; i++) {
                    for (var key in parsedPerson[i]) {
                        if (col.indexOf(key) === -1) {
                            col.push(key);
                        }
                    }
                }

                // CREATE DYNAMIC TABLE.
                var table = document.createElement("table");

                //Add the header row.
                var row = table.insertRow(-1);
                for (var i = 0; i < col.length; i++) {
                    var headerCell = document.createElement("th");
                    headerCell.innerHTML = col[i];
                    row.appendChild(headerCell);
                }
                //Add the data rows.
                for (var i = 0; i < parsedPerson.length; i++) {
                    row = table.insertRow(-1);
                    for (var j = 0; j < col.length; j++) {
                        var cell = row.insertCell(-1);
                        cell.innerHTML = parsedPerson[i][col[j]];
                    }
                }
                // FINALLY ADD THE NEWLY CREATED TABLE WITH JSON DATA TO A CONTAINER.
                var divContainer = document.getElementById("topDivision");
                divContainer.innerHTML = "";
                divContainer.appendChild(table);
            }
    };
}
function generatePersonDetail() {
    document.getElementById("bottomDivision").style.display = "block";
}
function submitRow() {
    var id = document.getElementById("id").value;
    var firstName = document.getElementById("firstName").value;
    var lastName = document.getElementById("lastName").value;
    var birthDate = document.getElementById("birthDate").value;
    var email = document.getElementById("email").value;
   
    document.cell[0].innerHTML = id;
    document.cell[1].innerHTML = firstName;
    document.cell[2].innerHTML = lastName;
    document.cell[3].innerHTML = birthDate;
    document.cell[4].innerHTML = email;
}
function resetToBlank() {
    document.getElementById('id').value = '';
    document.getElementById('firstName').value = '';
    document.getElementById('lastName').value = '';
    document.getElementById('birthDate').value = '';
    document.getElementById('email').value = '';
}
(function selectRow() {
    var table = document.getElementById("table");
    for ( var i = 1; i < table.rows.length; i++) {
        table.rows[i].onclick = function () {
            document.getElementById("id").value = this.cells[0].innerHTML;
            document.getElementById("firstName").value = this.cells[1].innerHTML;
            document.getElementById("lastName").value = this.cells[2].innerHTML;
            document.getElementById("birthDate").value = this.cells[3].innerHTML;
            document.getElementById("email").value = this.cells[4].innerHTML;
        };
    }
})();
// (function () {
    // if (window.addEventListener) {
        // window.addEventListener('load', run, false);
    // } else if (window.attachEvent) {
        // window.attachEvent('onload', run);
    // }

    // function run() {
        // var t = document.getElementById('myTable');
        // var rows = t.rows; 
        // for (var i=0; i<rows.length; i++) {
            // rows[i].onclick = function (event) {
                // if (this.parentNode.nodeName == 'THEAD') {
                    // return;
                // }
                // var cells = this.cells; //cells collection
                // var f1 = document.getElementById('id');
                // var f2 = document.getElementById('firstName');
                // var f3 = document.getElementById('lastName');
                // var f4 = document.getElementById('birthDate');
                // var f5 = document.getElementById('email');
                // f1.value = cells[0].innerHTML;
                // f2.value = cells[1].innerHTML;
                // f3.value = cells[2].innerHTML;
                // f4.value = cells[3].innerHTML;
                // f5.value = cells[4].innerHTML;
            // };
        // }
    // }

// })();


