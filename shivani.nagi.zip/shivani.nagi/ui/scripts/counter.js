var c = 0;
var t;
var timeIncrementor = function () {
    document.getElementById("timer").innerHTML = c++;
    t = setTimeout(timedCount, 5000);
}

