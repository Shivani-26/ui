var credentialValidator = function () {
  var user = document.forms["loginForm"]["Username"].value;
  if (user == "") {
    alert("UserName should not be empty");
  }
  var password = document.forms["loginForm"]["Password"].value;
    if (password == "") {
      alert("password should not be empty");
    }
}
