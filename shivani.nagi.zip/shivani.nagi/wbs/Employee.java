// create an Employee class with properties: id and name,a constructor which initializes name, a mechanism 
// to automatically assign id by incrementing the previous id. Create and print 10 employee objects using Object.toString()

public class Employee {
    
    int id;
    String name;
    
    Employee(String shivani) {
        name = shivani;
        
    }
    
    
}