package com.ofs.training.filter;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import com.ofs.training.service.ConnectionManager;

public class TransactionFilter implements Filter{

    @Override
    public void destroy() {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        ConnectionManager manager = new ConnectionManager();
        manager.initConnection();
        Connection connection = null;
        try {
            chain.doFilter(request, response);
            manager.releaseConnection(connection, true);
        } catch(Exception e) {
            manager.releaseConnection(connection, false);
        }
    }

    @Override
    public void init(FilterConfig arg0) throws ServletException {
    }
}
