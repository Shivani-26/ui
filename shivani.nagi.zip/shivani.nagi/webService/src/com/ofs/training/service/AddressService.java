package com.ofs.training.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class AddressService {

    Address address;

    public void validate(Address address, Connection connection) {

        ArrayList<Error> errorList = new ArrayList<>();
        int count = 0;

        if (address.getId() == 0) {
            errorList.add(Error.INVALID_ADDRESS_ID);
            count++;
        }

        if (address.getStreet() == null) {
            errorList.add(Error.INVALID_STREET);
            count++;
        }

        if (address.getCity() == null) {
            errorList.add(Error.INVALID_CITY);
            count++;
        }

        if(address.getPostalCode() == null) {
            errorList.add(Error.INVALID_POSTAL_CODE);
            count++;
        }

        if (count > 0) {
            throw new AppException(errorList);
        }
    }

    public Address create(Address address, Connection connection) {

        validate(address, connection);
        try {
            String query = "INSERT INTO address(street, city, postal_code) VALUES(?, ?, ?)";


            PreparedStatement statement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, address.getStreet());
            statement.setString(2, address.getCity());
            statement.setInt(3, address.getPostalCode());
            statement.executeUpdate();
            ResultSet result = statement.getGeneratedKeys();

            if (result.next()) {
                address.setId(result.getLong(1));
            }
            return address;
        } catch (SQLException exception) {
            throw new AppException(Error.SQL_EXCEPTION, exception.getCause());
        }
    }

    public Address update(Address address, Connection connection) throws Exception {

        try {
            validate(address, connection);
            String query = "UPDATE address SET street = ?, city = ?, postal_code = ? WHERE id = ?";

            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setString(1, address.getStreet());
            stmt.setString(2, address.getCity());
            stmt.setInt(3, address.getPostalCode());
            stmt.setLong(4, address.getId());
            stmt.executeUpdate();
            return address;
        } catch (SQLException exception) {
            throw new AppException(Error.SQL_EXCEPTION, exception.getCause());
        }
    }

    public ArrayList<Address> readAll(Connection connection) throws Exception {

        try {
            ArrayList<Address> records = new ArrayList<>();
            String select = "SELECT id, street, city, postal_code FROM address";
            PreparedStatement pstmt = connection.prepareStatement(select);
            ResultSet result = pstmt.executeQuery();
            while (result.next()) {
               Address address = new Address();
               address.setId(result.getInt("id"));
               address.setStreet(result.getString("street"));
               address.setCity(result.getString("city"));
               address.setPostalCode(result.getInt("postal_code"));
               records.add(address);
            }

            System.out.println(records);
            pstmt.close();
            return records;
        } catch (SQLException exception) {
            throw new AppException(Error.SQL_EXCEPTION, exception.getCause());
        }
    }

    public Address read(Address address, Connection connection) throws Exception {

        try {
            String select = "SELECT id, street, city, postal_code FROM address WHERE id = ?";

            if (address.getId() == 0) {
                throw new AppException(Error.INVALID_ADDRESS_ID);
            }
            PreparedStatement pstmt = connection.prepareStatement(select);
            pstmt.setLong(1, address.getId());
            ResultSet result = pstmt.executeQuery();

            result.next();
            address.setId(result.getLong("id"));
            address.setStreet(result.getString("street"));
            address.setCity(result.getString("city"));
            address.setPostalCode(result.getInt("postal_code"));
            return address;
        } catch (SQLException exception) {
            throw new AppException(Error.SQL_EXCEPTION, exception.getCause());
        }
    }

    public long delete(long id, Connection connection) throws Exception {

        try {
        String delete = "DELETE FROM address WHERE id = ?";

        if (id == 0) {
            throw new AppException(Error.INVALID_ADDRESS_ID);
        }

        PreparedStatement statement = connection.prepareStatement(delete);
        statement.setLong(1, id);

        int resultSet = statement.executeUpdate();
        System.out.println("record sucessfully deleted " + resultSet);
        } catch (SQLException exception) {
            throw new AppException(Error.SQL_EXCEPTION, exception.getCause());
        }
        return id;
    }

//    public static void main(String[] args) throws Exception {
//        AddressService addressService = new AddressService();
//        ConnectionManager connector = new ConnectionManager();
//        Connection connection = connector.initConnection("jdbc:mysql://pc1620:3306/shivani_nagi?useSSL=false&user=shivani_nagi&password=demo");
//
//        Address address = new Address();
//        address.setStreet("reddiyar st");
//        address.setCity("salem");
//        address.setPostalCode(636204);
//
//        System.out.println(addressService.create(address, connection));
//
//        Address addressOne = new Address();
//        addressOne.setStreet("gandhi nagar");
//        addressOne.setCity("salem");
//        addressOne.setPostalCode(235435);
//        System.out.println(addressService.create(addressOne, connection));
//
//        Address addressTwo = new Address();
//        addressTwo.setStreet("ay nagar");
//        addressTwo.setCity("salem");
//        addressTwo.setPostalCode(230035);
//        System.out.println(addressService.create(addressTwo, connection));
//
//        Address actAddress = new Address();
//        actAddress.setStreet("tharpaikadu");
//        actAddress.setPostalCode(787456);
//        actAddress.setId(2);
//        actAddress.setCity("salem");
//        System.out.println(addressService.update(actAddress, connection));
//
//        addressService.readAll(connection);
//        Address readAddress = new Address();
//        readAddress.setId(4);
//        System.out.println(addressService.read(readAddress, connection));
//
////        address.setId(1)
//        addressService.delete(5, connection);
////        connection.close();
//    }
}
