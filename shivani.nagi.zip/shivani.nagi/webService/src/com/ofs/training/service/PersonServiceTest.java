package com.ofs.training.service;

import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class PersonServiceTest {

        Person person;
        Address address;
        PersonService service;
        ConnectionManager manager = new ConnectionManager();
        Connection connection;
        AddressService addressService;
       @BeforeClass
        private void initClass() {
            addressService = new AddressService();
            service = new PersonService(addressService);
            address = new Address();
        }
        @Test(dataProvider = "testCreate_positiveDP")
        private void testCreate_positive(Person person, Person expectedResult) {
            try {
                connection = manager.initConnection();
                Person actualResult = service.create(person, connection);
                Assert.assertEquals(actualResult.toString(), expectedResult.toString());
                connection.commit();
            } catch (Exception e) {
//                e.getMessage();
                Assert.fail("unexpected exception " 
                        + person.getFirstname()
                        + person.getLastname()
                        + person.getEmail()
                        + person.getBirthDate()
//                        + person
                        + "Expected result is "
                        + expectedResult
                        + ". ",
                        e);
            }
        }
        @DataProvider
        private Object[][] testCreate_positiveDP() {
            Person personSetter = new Person();
            personSetter.setId(1);
            personSetter.setFirstname("shiv");
            personSetter.setLastname("ani");
            personSetter.setEmail("shiv@gmail.com");
            personSetter.setBirthDate(Date.valueOf("1996-05-26"));
            personSetter.setAdmin(true);

            Address address = new Address();
            address.setId(1);
            address.setStreet("A st");
            address.setCity("slm");
            address.setPostalCode(457576);
            personSetter.setAddress(address);

            Person expectedPerson = new Person();
            expectedPerson.setId(1);
            expectedPerson.setFirstname("shiv");
            expectedPerson.setLastname("ani");
            expectedPerson.setEmail("shiv@gmail.com");
            expectedPerson.setBirthDate(Date.valueOf("1996-05-26"));
            expectedPerson.setAddress(address);

            Person personSetterOne = new Person();
            personSetterOne.setId(2);
            personSetterOne.setFirstname("ruchi");
            personSetterOne.setLastname("ra");
            personSetterOne.setEmail("ruchi@gmail.com");
            personSetterOne.setBirthDate(Date.valueOf("2000-12-23"));
            personSetterOne.setAdmin(false);

            Address addressOne = new Address();
            addressOne.setId(2);
            addressOne.setStreet("B st");
            addressOne.setCity("cbe");
            addressOne.setPostalCode(546568);
            personSetterOne.setAddress(addressOne);

            Person expectedPersonOne = new Person();
            expectedPersonOne.setId(2);
            expectedPersonOne.setFirstname("ruchi");
            expectedPersonOne.setLastname("ra");
            expectedPersonOne.setEmail("ruchi@gmail.com");
            expectedPersonOne.setBirthDate(Date.valueOf("2000-12-23"));
            expectedPersonOne.setAddress(addressOne);

            Person personSetterTwo = new Person();
            personSetterTwo.setId(3);
            personSetterTwo.setFirstname("selva");
            personSetterTwo.setLastname("rani");
            personSetterTwo.setEmail("rani@gmail.com");
            personSetterTwo.setBirthDate(Date.valueOf("1974-12-07"));
            personSetterTwo.setAdmin(true);

            Address addressTwo = new Address();
            addressTwo.setId(3);
            addressTwo.setStreet("A st");
            addressTwo.setCity("slm");
            addressTwo.setPostalCode(457576);
            personSetterTwo.setAddress(addressTwo);

            Person expectedPersonTwo = new Person();
            expectedPersonTwo.setId(3);
            expectedPersonTwo.setFirstname("selva");
            expectedPersonTwo.setLastname("rani");
            expectedPersonTwo.setEmail("rani@gmail.com");
            expectedPersonTwo.setBirthDate(Date.valueOf("1974-12-07"));
            expectedPersonTwo.setAddress(addressTwo);

            return new Object[][] {
                {personSetter, expectedPerson},
                {personSetterOne, expectedPersonOne},
                {personSetterTwo, expectedPersonTwo}
            };
        }

        @Test(dataProvider = "testCreate_negative1_DP")
        private void testCreate_negative1(Person person, AppException expected) throws Exception {

            try {
                connection = manager.initConnection();
                service.create(person, connection);
                Assert.fail("Expected an exception");
                connection.commit();
            } catch (AppException e) {
                Assert.assertEquals(e.getMessage(), expected.getMessage());
                connection.rollback();
            }
        }

        @DataProvider
        private Object[][] testCreate_negative1_DP() {
            Person personSetter = new Person();
            personSetter.setId(1);
            personSetter.setFirstname(null);
            personSetter.setLastname("ani");
            personSetter.setEmail("shiv@gmail.com");
            personSetter.setBirthDate(Date.valueOf("1996-05-26"));

            Address address = new Address();
            address.setStreet("A st");
            address.setCity("slm");
            address.setPostalCode(457576);
            personSetter.setAddress(address);
            
            ArrayList<Error> errors = new ArrayList<>();
            errors.add(Error.INVALID_FIRST_NAME);

            Person personSetterOne = new Person();
            personSetterOne.setId(1);
            personSetterOne.setFirstname("shiv");
            personSetterOne.setLastname(null);
            personSetterOne.setEmail("shiv@gmail.com");
            personSetterOne.setBirthDate(Date.valueOf("1996-05-26"));

            Address addressOne = new Address();
            addressOne.setStreet("A st");
            addressOne.setCity("slm");
            addressOne.setPostalCode(457576);
            personSetterOne.setAddress(addressOne);

            ArrayList<Error> errorOne = new ArrayList<>();
            errorOne.add(Error.INVALID_LAST_NAME);

            Person personSetterTwo = new Person();
            personSetterTwo.setId(1);
            personSetterTwo.setFirstname("shiv");
            personSetterTwo.setLastname("ani");
            personSetterTwo.setEmail(null);
            personSetterTwo.setBirthDate(Date.valueOf("1996-05-26"));

            Address addressTwo = new Address();
            addressTwo.setStreet("A st");
            addressTwo.setCity("slm");
            addressTwo.setPostalCode(457576);
            personSetterTwo.setAddress(addressTwo);

            ArrayList<Error> errorTwo = new ArrayList<>();
            errorTwo.add(Error.DUPLICATE_EMAIL);

            Person personSetterThree = new Person();
            personSetterThree.setId(1);
            personSetterThree.setFirstname("shiv");
            personSetterThree.setLastname("ani");
            personSetterThree.setEmail("shiv@gmail.com");
            personSetterThree.setBirthDate(null);

            Address addressThree = new Address();
            addressThree.setStreet("A st");
            addressThree.setCity("slm");
            addressThree.setPostalCode(457576);
            personSetterThree.setAddress(addressThree);

            ArrayList<Error> errorThree = new ArrayList<>();
            errorThree.add(Error.INVALID_BIRTH_DATE);

            Person personSetterFour = new Person();
            personSetterFour.setId(1);
            personSetterFour.setFirstname("shiv");
            personSetterFour.setLastname("ani");
            personSetterFour.setEmail("shiv@gmail.com");
            personSetterFour.setBirthDate(Date.valueOf("1996-05-26"));

            Address addressFour = new Address();
            addressFour.setStreet(null);
            addressFour.setCity("slm");
            addressFour.setPostalCode(457576);
            personSetterFour.setAddress(addressFour);

            ArrayList<Error> errorFour = new ArrayList<>();
            errorFour.add(Error.INVALID_STREET);

            Person personSetterFive = new Person();
            personSetterFive.setId(1);
            personSetterFive.setFirstname("shiv");
            personSetterFive.setLastname("ani");
            personSetterFive.setEmail("shiv@gmail.com");
            personSetterFive.setBirthDate(Date.valueOf("1996-05-26"));
            
            Address addressFive = new Address();
            addressFive.setStreet("A st");
            addressFive.setCity(null);
            addressFive.setPostalCode(457576);
            personSetterFive.setAddress(addressFive);
            
            ArrayList<Error> errorFive = new ArrayList<>();
            errorFive.add(Error.INVALID_CITY);

            Person personSetterSix = new Person();
            personSetterSix.setId(1);
            personSetterSix.setFirstname("shiv");
            personSetterSix.setLastname("ani");
            personSetterSix.setEmail("shiv@gmail.com");
            personSetterSix.setBirthDate(Date.valueOf("1996-05-26"));

            Address addressSix = new Address();
            addressSix.setStreet("A st");
            addressSix.setCity("slm");
            addressSix.setPostalCode(null);
            personSetterSix.setAddress(addressSix);

            ArrayList<Error> errorSix = new ArrayList<>();
            errorSix.add(Error.INVALID_POSTAL_CODE);

            return new Object[][] {
                {personSetter, new AppException(errors)},
                {personSetterOne, new AppException(errorOne)},
                {personSetterTwo, new AppException(errorTwo)},
                {personSetterThree, new AppException(errorThree)},
                {personSetterFour, new AppException(errorFour)},
                {personSetterFive, new AppException(errorFive)},
                {personSetterSix, new AppException(errorSix)}
            };
        }

        @Test(dataProvider = "testRead_positiveDP")
        private void testRead_positive(Person person, boolean includeAddress, Person expectedResult) {
            try {
                connection = manager.initConnection();
                Person actualResult = service.read(person, includeAddress, connection);
                Assert.assertEquals(actualResult.toString(), expectedResult.toString());
                connection.commit();
            } catch (Exception e) {
                Assert.fail(
                        "unexpected exception "
                            + person.getId()
                            + "Expected result is "
                            + expectedResult
                            + ".",
                            e);
//                System.out.println(e.getMessage());
            }
        }

        @DataProvider
        private Object[][] testRead_positiveDP() {
            Person personReader = new Person();
            personReader.setId(3);

            Person ExpectedPersonReader = new Person();
            ExpectedPersonReader.setId(3);
            ExpectedPersonReader.setFirstname("selva");
            ExpectedPersonReader.setLastname("rani");
            ExpectedPersonReader.setEmail("rani@gmail.com");
            ExpectedPersonReader.setBirthDate(Date.valueOf("1974-12-07"));
            ExpectedPersonReader.setAdmin(true);

            Address address = new Address();
            address.setId(3);
            address.setStreet("A st");
            address.setCity("slm");
            address.setPostalCode(457576);

            ExpectedPersonReader.setAddress(address);
            return new Object[][] {
                {personReader, true, personReader}
            };
        }

        @Test(dataProvider = "testRead_negative_DP")
        private void testRead_negative(Person person, boolean includePerson, AppException exception) throws Exception {


            try {
                connection = manager.initConnection();
                service.read(person, includePerson, connection);
                Assert.fail("Expected an Exception");
                connection.rollback();
            } catch (Exception e) {
                Assert.assertEquals(e.getMessage(), exception.getMessage());
                connection.rollback();
            }
            
        }
        @DataProvider
        private Object[][] testRead_negative_DP() {
            Person personReader = new Person();
            personReader.setId(0);

            ArrayList<Error> errors = new ArrayList<>();
            errors.add(Error.INVALID_PERSON_ID);
            return new Object[][] {
                {personReader, true, new AppException(errors)}
            };
        }

        @Test(dataProvider = "testUpdate_positiveDP")
        private void testupdateCheck_positive1(Person person, Person expectedResult) throws Exception {
    
            try {
                connection = manager.initConnection();
                Person actualResult = service.update(person, connection);
                Assert.assertEquals(actualResult.toString(), expectedResult.toString());
                connection.commit();
            } catch (AppException e) {
//                Assert.fail(new StringBuilder()
//                        .append("Unexpected exception for input ")
//                        .append(person.getFirstname())
//                        .append(" , ")
//                        .append(person.getLastname())
//                        .append(" , ")
//                        .append(person.getEmail())
//                        .append(" , ")
//                        .append(person.getBirthDate())
//                        .append(" , ")
//                        .append(person.getId())
//                        .append(" , ")
//                        .append("Expected result is ")
//                        .append(expectedResult).toString());
                Assert.fail("unexpected exception"
                        + person
                        + "Expected result is "
                        + expectedResult
                        + ". ",
                        e);
                connection.rollback();
            }
        }
        @DataProvider
        private Object[][] testUpdate_positiveDP() {

            Person person = new Person();

            person.setFirstname("jothi");
            person.setLastname("jaya");
            person.setEmail("jothi@gmail.com");
            person.setBirthDate(Date.valueOf("1958-09-03"));
            person.setId(1);

            Address address = new Address();
            address.setId(1);
            address.setStreet("reddi street");
            address.setCity("salem");
            address.setPostalCode(636204);
            person.setAddress(address);

            Address addressOne = new Address();
            addressOne.setId(1);
            addressOne.setStreet("reddi street");
            addressOne.setCity("salem");
            addressOne.setPostalCode(636204);

            Person expectedPerson = new Person();
            expectedPerson.setFirstname("jothi");
            expectedPerson.setLastname("jaya");
            expectedPerson.setEmail("jothi@gmail.com");
            expectedPerson.setBirthDate(Date.valueOf("1958-09-03"));
            expectedPerson.setId(1);
            expectedPerson.setAddress(addressOne);

            return new Object[][] {
                { person, expectedPerson}
            };
        }

        @Test(dataProvider = "testUpdate_negativeDP")
        private void testUpdateCheck_negative(Person person, AppException expectedValue) throws Exception {

            try {
                connection = manager.initConnection();
                service.update(person, connection);;
                Assert.fail("Expected an exception.");
            } catch (AppException e) {
                Assert.assertEquals(e.getMessage(), expectedValue.getMessage()) ;
            }
        }
        @DataProvider
        private Object [][] testUpdate_negativeDP(AppException exception) throws Exception {
            Person person  = new Person();
            person.setId(0);
            person.setEmail("shiv");
            person.setFirstname("ani");
            person.setLastname("shiv@gmail.com");
            person.setBirthDate(Date.valueOf("1978-12-21"));

            Address address = new Address();
            address.setStreet("reddiyar street");
            address.setCity("salem");
            address.setPostalCode(654545);
            person.setAddress(address);

            ArrayList<Error> errors = new ArrayList<>();
            errors.add(Error.INVALID_PERSON_ID);

            Person personSetterOne = new Person();
            personSetterOne.setId(1);
            personSetterOne.setFirstname("shiv");
            personSetterOne.setLastname(null);
            personSetterOne.setEmail("shiv@gmail.com");
            personSetterOne.setBirthDate(Date.valueOf("1996-05-26"));

            Address addressOne = new Address();
            addressOne.setStreet("A st");
            addressOne.setCity("slm");
            addressOne.setPostalCode(457576);
            personSetterOne.setAddress(addressOne);

            ArrayList<Error> errorOne = new ArrayList<>();
            errorOne.add(Error.INVALID_LAST_NAME);

            Person personSetterTwo = new Person();
            personSetterTwo.setId(1);
            personSetterTwo.setFirstname("shiv");
            personSetterTwo.setLastname("ani");
            personSetterTwo.setEmail(null);
            personSetterTwo.setBirthDate(Date.valueOf("1996-05-26"));

            Address addressTwo = new Address();
            addressTwo.setStreet("A st");
            addressTwo.setCity("slm");
            addressTwo.setPostalCode(457576);
            personSetterTwo.setAddress(addressTwo);

            ArrayList<Error> errorTwo = new ArrayList<>();
            errorTwo.add(Error.DUPLICATE_EMAIL);

            Person personSetterThree = new Person();
            personSetterThree.setId(1);
            personSetterThree.setFirstname("shiv");
            personSetterThree.setLastname("ani");
            personSetterThree.setEmail("shiv@gmail.com");
            personSetterThree.setBirthDate(null);

            Address addressThree = new Address();
            addressThree.setStreet("A st");
            addressThree.setCity("slm");
            addressThree.setPostalCode(457576);
            personSetterThree.setAddress(addressThree);

            ArrayList<Error> errorThree = new ArrayList<>();
            errorThree.add(Error.INVALID_BIRTH_DATE);

            Person personSetterFour = new Person();
            personSetterFour.setId(1);
            personSetterFour.setFirstname("shiv");
            personSetterFour.setLastname("ani");
            personSetterFour.setEmail("shiv@gmail.com");
            personSetterFour.setBirthDate(Date.valueOf("1996-05-26"));

            Address addressFour = new Address();
            addressFour.setStreet(null);
            addressFour.setCity("slm");
            addressFour.setPostalCode(457576);
            personSetterFour.setAddress(addressFour);

            ArrayList<Error> errorFour = new ArrayList<>();
            errorFour.add(Error.INVALID_STREET);

            Person personSetterFive = new Person();
            personSetterFive.setId(1);
            personSetterFive.setFirstname("shiv");
            personSetterFive.setLastname("ani");
            personSetterFive.setEmail("shiv@gmail.com");
            personSetterFive.setBirthDate(Date.valueOf("1996-05-26"));
            
            Address addressFive = new Address();
            addressFive.setStreet("A st");
            addressFive.setCity(null);
            addressFive.setPostalCode(457576);
            personSetterFive.setAddress(addressFive);
            
            ArrayList<Error> errorFive = new ArrayList<>();
            errorFive.add(Error.INVALID_CITY);

            Person personSetterSix = new Person();
            personSetterSix.setId(1);
            personSetterSix.setFirstname("shiv");
            personSetterSix.setLastname("ani");
            personSetterSix.setEmail("shiv@gmail.com");
            personSetterSix.setBirthDate(Date.valueOf("1996-05-26"));

            Address addressSix = new Address();
            addressSix.setStreet("A st");
            addressSix.setCity("slm");
            addressSix.setPostalCode(null);
            personSetterSix.setAddress(addressSix);

            ArrayList<Error> errorSix = new ArrayList<>();
            errorSix.add(Error.INVALID_POSTAL_CODE);

            return new Object[][] {
                {person, new AppException(errors)},
                {personSetterOne, new AppException(errorOne)},
                {personSetterTwo, new AppException(errorTwo)},
                {personSetterThree, new AppException(errorThree)},
                {personSetterFour, new AppException(errorFour)},
                {personSetterFive, new AppException(errorFive)},
                {personSetterSix, new AppException(errorSix)}
            };

        }

        @Test(dataProvider = "testReadAll_positiveDP")
        private void testReadAll_positiveDP(ArrayList<Person> list) {
            try {
                connection = manager.initConnection();
                ArrayList<Person> actualResult = service.readAll(connection);
                Assert.assertEquals(actualResult.toString(), list.toString());
                connection.commit();
            } catch (Exception e) {
                Assert.fail("unexpected exception"
                            + "Expected result is"
                            + list
                            + ".",
                            e);
            }
        }
        @DataProvider
        private Object[][] testReadAll_positiveDP() {
            ArrayList<Person> list = new ArrayList<>(); 
            Person personSetter = new Person();
            personSetter.setId(1);
            personSetter.setFirstname("jothi");
            personSetter.setLastname("jaya");
            personSetter.setEmail("jothi@gmail.com");
            personSetter.setBirthDate(Date.valueOf("1958-09-03"));
            personSetter.setAdmin(true);

            Address address = new Address();
            address.setId(1);
            address.setStreet("A st");
            address.setCity("slm");
            address.setPostalCode(457576);
            personSetter.setAddress(address);
            list.add(personSetter);

            Person personSetterOne = new Person();
            personSetterOne.setId(2);
            personSetterOne.setFirstname("ruchi");
            personSetterOne.setLastname("ra");
            personSetterOne.setEmail("ruchi@gmail.com");
            personSetterOne.setBirthDate(Date.valueOf("2000-12-23"));
            personSetterOne.setAdmin(false);

            Address addressOne = new Address();
            addressOne.setId(2);
            addressOne.setStreet("B st");
            addressOne.setCity("cbe");
            addressOne.setPostalCode(546568);
            personSetterOne.setAddress(addressOne);

            Person expectedPersonOne = new Person();
            expectedPersonOne.setId(2);
            expectedPersonOne.setFirstname("ruchi");
            expectedPersonOne.setLastname("ra");
            expectedPersonOne.setEmail("ruchi@gmail.com");
            expectedPersonOne.setBirthDate(Date.valueOf("2000-12-23"));
            expectedPersonOne.setAddress(addressOne);

            Person personSetterTwo = new Person();
            personSetterTwo.setId(3);
            personSetterTwo.setFirstname("selva");
            personSetterTwo.setLastname("rani");
            personSetterTwo.setEmail("rani@gmail.com");
            personSetterTwo.setBirthDate(Date.valueOf("1974-12-07"));
            personSetterTwo.setAdmin(true);

            Address addressTwo = new Address();
            addressTwo.setId(3);
            addressTwo.setStreet("A st");
            addressTwo.setCity("slm");
            addressTwo.setPostalCode(457576);
            personSetterTwo.setAddress(addressTwo);

            Person expectedPersonTwo = new Person();
            expectedPersonTwo.setId(3);
            expectedPersonTwo.setFirstname("selva");
            expectedPersonTwo.setLastname("rani");
            expectedPersonTwo.setEmail("rani@gmail.com");
            expectedPersonTwo.setBirthDate(Date.valueOf("1974-12-07"));
            expectedPersonTwo.setAddress(addressTwo);
            return new Object[][] {
                {list}
            };
        }

        @Test(dataProvider = "testDelete_positiveDP")
        private void testDelete_positive(long id) throws Exception {
            try {
                service.delete(id, connection);
                connection.commit();
            }
            catch(AppException e) {
                Assert.fail("Unexpected exception for given input "
                        +".Expected value is "
                        + person.getId()
                        + ".",
                        e);
            connection.rollback();
            }
        }

        @DataProvider
        private Object[][] testDelete_positiveDP() {

            return new Object[][] {
                {1}
            };
        }
        @Test(dataProvider = "testDelete_negativeDP")
        private void testDelete_negative1(long id, AppException expected) throws Exception {

            try {
                service.delete(id, connection);
                Assert.fail("Expected an exception.");
                connection.commit();
            } catch (AppException e) {
                System.out.println(e.getMessage());
                Assert.assertEquals(e.getMessage(), expected.getMessage());
                connection.rollback();
            }
        }
        @DataProvider
        private Object[][] testDelete_negativeDP() {

            ArrayList<Error> errors = new ArrayList<>();
            errors.add(Error.INVALID_PERSON_ID);
            return new Object[][] {
                {0, new AppException(errors)}
            };
        }

        @AfterClass
        private void Teardown() throws Exception {
            service = null;
            connection.close();
        }
    }
