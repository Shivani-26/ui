package com.ofs.training.servlet;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ofs.training.service.AppException;
import com.ofs.training.service.AuthenticationService;
import com.ofs.training.service.Person;
import com.ofs.training.service.Error;

public class AuthenticationServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    public void doGet(HttpServletRequest request, HttpServletResponse response) {

        String email = request.getParameter("email");
        String password = request.getParameter("password");
        AuthenticationService serviceCaller = new AuthenticationService();
        Person person = new Person();
        try {
            person = serviceCaller.login(email, password);
        } catch (Exception e) {
            throw new AppException(Error.UNAUTHENTICATED_USER, e.getCause());
        }
        HttpSession session = request.getSession();
        String sessionId = session.getId();
        response.setHeader("sessionId", sessionId);
        session.setAttribute("person", person);
    }
}
