package com.ofs.training.test;

import java.util.ArrayList;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.ofs.training.resource.HttpMethod;
import com.ofs.training.resource.JsonUtil;
import com.ofs.training.resource.RequestHelper;
import com.ofs.training.service.Address;
import com.ofs.training.service.AppException;
import com.ofs.training.service.Error;

public class AddressServletTest extends TestBaseServlet {

    RequestHelper helper;

    @BeforeClass
    private void initClass() {
        helper = new RequestHelper();
        RequestHelper.setBaseUrl("http://localhost:8080/ws/");
    }

    @Test(dataProvider = "testPut_dp")
    private void testPut_positive(Address address) throws Exception {

        Address actualResult = helper.setMethod(HttpMethod.PUT)
                .setInput(address)
                .requestObject("address", Address.class);
        Assert.assertEquals(JsonUtil.toJson(actualResult), JsonUtil.toJson(address));

    }

    @DataProvider
    private Object[][] testPut_dp() {

        Address address = new Address();
        address.setId(1);
        address.setStreet("aaa street");
        address.setCity("salem");
        address.setPostalCode(636087);

        Address addressOne = new Address();
        addressOne.setId(2);
        addressOne.setStreet("bbb street");
        addressOne.setCity("salem");
        addressOne.setPostalCode(636006);

        return new Object[][] {
            {address},
            {addressOne}
        };
    }
    @Test(dataProvider = "testPost_dp")
    private void testPost_positive(Address address, Address expectedAddress, long id) throws Exception {

        Address actualResult = helper.setMethod(HttpMethod.POST)
                .setInput(address)
                .requestObject(String.format("http://localhost:8080/ws/address?id=%d", id), Address.class);
        Assert.assertEquals(JsonUtil.toJson(actualResult), JsonUtil.toJson(expectedAddress));
    }
    @DataProvider
    private Object[][] testPost_dp() {
        
        Address address = new Address();
        address.setId(1);
        address.setStreet("ccc street");
        address.setCity("cbe");
        address.setPostalCode(636087);
        
        Address addressOne = new Address();
        addressOne.setId(2);
        addressOne.setStreet("ddd street");
        addressOne.setCity("erode");
        addressOne.setPostalCode(636006);
        return new Object[][] {
            {address, address, 1},
            {addressOne, addressOne, 2}
        };
    }

    
    @Test(dataProvider = "testPost_negativedp")
    private void testPost_negative(Address address, String url, AppException expected) throws Exception {
        String actualResult = helper.setMethod(HttpMethod.POST)
//                .setInput(address)
                .requestString(url);
        Assert.assertEquals(actualResult,  JsonUtil.toJson(expected));
    }
    @DataProvider
    private Object[][] testPost_negativedp() {
        Address address = new Address();
        address.setId(1);
        address.setStreet("ccc street");
        address.setCity("cbe");
        address.setPostalCode(636087);

        AppException error = new AppException(Error.URL_ERR);
        return new Object[][] {
                {address,  "http://localhost:8080/address?id=abc", error}
        };
    }
    
    @Test(dataProvider = "testGet_dp")
    private void testGet_positive(Address address, long id) throws Exception {

        Address actualResult = helper.setMethod(HttpMethod.GET)
                .requestObject(String.format("http://localhost:8080/ws/address?id=%d", id), Address.class);
        Assert.assertEquals(JsonUtil.toJson(actualResult), JsonUtil.toJson(address));

    }
    @DataProvider
    private Object[][] testGet_dp() {

        Address address = new Address();
        address.setId(1);
        address.setStreet("ccc street");
        address.setCity("cbe");
        address.setPostalCode(636087);

        Address addressOne = new Address();
        addressOne.setId(2);
        addressOne.setStreet("ddd street");
        addressOne.setCity("erode");
        addressOne.setPostalCode(636006);

        return new Object[][] {
            {address, 1},
            {addressOne, 2}
        };
    }

    @Test(dataProvider = "testGet_negativedp")
    private void testGet_negative(String url, AppException expected) throws Exception {
        String actualResult = helper.setMethod(HttpMethod.GET)
                .requestString(url);
        Assert.assertEquals(actualResult,  JsonUtil.toJson(expected.toString()));
    }
    @DataProvider
    private Object[][] testGet_negativedp() {

        AppException error = new AppException(Error.URL_ERR);
        return new Object[][] {
                { "http://localhost:8080/address?id=", error}
//            { "http://localhost:8080/address?sd", Error.ID_INVALID},
//            { "http://localhost:8080/address?id=", Error.ID_NULL}
        };
    }
    
    @Test(dataProvider = "testGetAll_dp")
    private void testGetAll_positive(ArrayList<Address> address) throws Exception {

        String actualResult = helper.setMethod(HttpMethod.GET)
                //                .setInput(address)
                .requestString("http://localhost:8080/ws/address");
        Assert.assertEquals( actualResult, JsonUtil.toJson(address));

    }

    @DataProvider
    private Object[][] testGetAll_dp() {

        Address address = new Address();
        address.setId(1);
        address.setStreet("ccc street");
        address.setCity("cbe");
        address.setPostalCode(636087);

        Address addressOne = new Address();
        addressOne.setId(2);
        addressOne.setStreet("ddd street");
        addressOne.setCity("erode");
        addressOne.setPostalCode(636006);

        ArrayList<Address> lists = new ArrayList<>();
        lists.add(address);
        lists.add(addressOne);

        return new Object[][] {

            {lists}
        };
    }

    @Test(dataProvider = "testDelete_dp")
    private void testDelete_positive(long id, int expectedValue) throws Exception {

        int actualResult = helper.setMethod(HttpMethod.DELETE)
                .setInput(null)
                .requestObject(String.format("http://localhost:8080/ws/address?id=%d", id), Integer.class);
        Assert.assertEquals(JsonUtil.toJson(actualResult), JsonUtil.toJson(expectedValue));

    }

    @DataProvider
    private Object[][] testDelete_dp() {
        return new Object[][] {
            {1, 1},
            {2, 1}
        };
    }
    @AfterClass
    private void Teardown() throws Exception {
        helper = null;
    }
}
