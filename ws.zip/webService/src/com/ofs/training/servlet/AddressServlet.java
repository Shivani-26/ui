package com.ofs.training.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ofs.training.resource.JsonUtil;
import com.ofs.training.service.Address;
import com.ofs.training.service.AddressService;
import com.ofs.training.service.AppException;
import com.ofs.training.service.ConnectionManager;
import com.ofs.training.service.Error;

public class AddressServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    ConnectionManager connectionManager  =  new ConnectionManager();
    Connection conn = connectionManager.initConnection();
    AddressService addressService = new AddressService();
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("application/json");
        PrintWriter printWriter = response.getWriter();
        String id = request.getParameter("id");
        Address address = new Address();

        if(Objects.isNull(id)) {
            try {
              conn = connectionManager.initConnection();
                ArrayList<Address> addresses = new ArrayList<>();
                addresses = addressService.readAll(conn);
                String addressJson = JsonUtil.toJson(addresses);
                printWriter.write(addressJson);
//                for (Address address1 : addresses) {
//                    printWriter.write(JsonUtil.toJson(address1));
//                }
                    conn.commit();
                printWriter.close();
                conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            try {
                conn = connectionManager.initConnection();
                long rid = Long.parseLong(id);
                address.setId(rid);
                String readResult = JsonUtil.toJson(addressService.read(address, conn));
                printWriter.write(readResult);
                conn.commit();
                conn.close();

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    } 
    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Reading payload(Input) as JSON using reader
        response.setContentType("application/json");
        BufferedReader reader = request.getReader();
        List<String> jsonLines = reader.lines().collect(Collectors.toList()); //or use readLine() Method while while block
        String addressJson = String.join("", jsonLines); //or use readLine() Method while while block
        System.out.format("Input JSON >> %s", addressJson);
        
        //Converting JSON to Object
        Address address = JsonUtil.toObject(addressJson, Address.class);
        try {
            conn = connectionManager.initConnection();
            Address createAddress = addressService.create(address, conn);
            String createdAddress = JsonUtil.toJson(createAddress);
            PrintWriter printWriter = response.getWriter();
            printWriter.write(createdAddress);
            conn.commit();
        } catch (Exception e) {
            e.printStackTrace();
            try {
                conn.rollback();
            } catch (SQLException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
        }
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Reading payload(Input) as JSON using reader
        BufferedReader reader = request.getReader();
        List<String> jsonLines = reader.lines().collect(Collectors.toList()); //or use readLine() Method while while block
        String addressJson = String.join("", jsonLines); //or use readLine() Method while while block
        System.out.format("Input JSON >> %s", addressJson);

        //Converting JSON to Object
        Address address = JsonUtil.toObject(addressJson, Address.class);
        try {
            Address createAddress = addressService.update(address, conn);
            String createdAddress = JsonUtil.toJson(createAddress);
            PrintWriter printWriter = response.getWriter();
            printWriter.write(createdAddress);
            conn.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter printWriter = response.getWriter();
        String id = request.getParameter("id");
        long parsedId = Long.parseLong(id);
//        Address address = new Address();
//        address.setId(parsedId);

            try {
              conn = connectionManager.initConnection();
              long deletedId = addressService.delete(parsedId, conn);
              printWriter.println(deletedId);
              conn.commit();
            } catch (Exception e) {
                e.printStackTrace();
            }
    }
}
