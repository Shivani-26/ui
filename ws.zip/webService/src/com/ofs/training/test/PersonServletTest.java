package com.ofs.training.test;

import java.sql.Date;
import java.util.ArrayList;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.ofs.training.resource.HttpMethod;
import com.ofs.training.resource.JsonUtil;
import com.ofs.training.resource.RequestHelper;
import com.ofs.training.service.Address;
import com.ofs.training.service.AppException;
import com.ofs.training.service.Person;

public class PersonServletTest extends TestBaseServlet{
    RequestHelper helper;

    @BeforeClass
    private void initClass() {
        helper = new RequestHelper();
        RequestHelper.setBaseUrl("http://localhost:8080/ws/");
    }
    @Test(dataProvider = "testPut_dp")
    private void testPut_positive(Person person) throws Exception {

        Person actualResult = helper.setMethod(HttpMethod.PUT)
                .setInput(person)
                .requestObject("person", Person.class);
        Assert.assertEquals(JsonUtil.toJson(actualResult), JsonUtil.toJson(person));

    }
    @DataProvider
    private Object[][] testPut_dp() {

        Person personSetterOne = new Person();
        personSetterOne.setId(1);
        personSetterOne.setFirstname("ruchira");
        personSetterOne.setLastname("reddi");
        personSetterOne.setEmail("shiv@gmail.com");
        personSetterOne.setBirthDate(Date.valueOf("2000-12-23"));

        Address addressOne = new Address();
        addressOne.setId(1);
        addressOne.setStreet("B st");
        addressOne.setCity("slm");
        addressOne.setPostalCode(458525);
        personSetterOne.setAddress(addressOne);

        Person personSetterTwo = new Person();
        personSetterTwo.setId(2);
        personSetterTwo.setFirstname("selva");
        personSetterTwo.setLastname("rani");
        personSetterTwo.setEmail("rani@gmail.com");
        personSetterTwo.setBirthDate(Date.valueOf("1974-12-07"));

        Address addressTwo = new Address();
        addressTwo.setId(2);
        addressTwo.setStreet("C st");
        addressTwo.setCity("slm");
        addressTwo.setPostalCode(875452);
        personSetterTwo.setAddress(addressTwo);
        return new Object[][] {
            {personSetterOne},
            {personSetterTwo}
        };
    }
    @Test(dataProvider = "testPost_dp")
    private void testPost_positive(Person person, Person expectedPerson, long id) throws Exception {

        Person actualResult = helper.setMethod(HttpMethod.POST)
                .setInput(person)
                .requestObject(String.format("person?id=%d", id), Person.class);
        Assert.assertEquals(JsonUtil.toJson(actualResult), JsonUtil.toJson(expectedPerson));
    }
    @DataProvider
    private Object[][] testPost_dp() {
        Person personSetter = new Person();
        personSetter.setId(1);
        personSetter.setFirstname("jothi");
        personSetter.setLastname("jaya");
        personSetter.setEmail("jothi@gmail.com");
        personSetter.setBirthDate(Date.valueOf("1960-04-06"));

        Address address = new Address();
        address.setId(1);
        address.setStreet("B st");
        address.setCity("salem");
        address.setPostalCode(585875);
        personSetter.setAddress(address);
        return new Object[][] {
            {personSetter, personSetter, 1}
        };
    }
    @Test(dataProvider = "testPost_negativedp")
    private void testPost_negative(Person person, String url, AppException expected) throws Exception {
        String actualResult = helper.setMethod(HttpMethod.POST)
                //                .setInput(address)
                .requestString(url);
        Assert.assertEquals(actualResult,  JsonUtil.toJson(expected));
    }
    @DataProvider
    private Object[][] testPost_negativedp() {
        Person personSetter = new Person();
        personSetter.setId(1);
        personSetter.setFirstname("jothi");
        personSetter.setLastname("jaya");
        personSetter.setEmail("jothi@gmail.com");
        personSetter.setBirthDate(Date.valueOf("1960-04-06"));

        Address address = new Address();
        address.setId(1);
        address.setStreet("ccc street");
        address.setCity("cbe");
        address.setPostalCode(636087);
        personSetter.setAddress(address);

        return new Object[][] {
            //                {personSetter,  "http://localhost:8080/person?id=abc", new AppException(Error.URL_ERR)}
        };
    }
    @Test(dataProvider = "testGet_dp")
    private void testGet_positive(Person person, long id, boolean includeAddress) throws Exception {

        String actualResult = helper.setMethod(HttpMethod.GET)
                .requestString("person?id=1&includeAddress=true");
        Assert.assertEquals(actualResult, JsonUtil.toJson(person));

    }
    @DataProvider
    private Object[][] testGet_dp() {

        Person personSetterOne = new Person();
        personSetterOne.setId(1);
        personSetterOne.setFirstname("ruchira");
        personSetterOne.setLastname("reddi");
        personSetterOne.setEmail("shiv@gmail.com");
        personSetterOne.setBirthDate(Date.valueOf("2000-12-23"));
        personSetterOne.setAddressId(1);

        Address addressOne = new Address();
        addressOne.setId(1);
        addressOne.setStreet("B st");
        addressOne.setCity("slm");
        addressOne.setPostalCode(458525);
        personSetterOne.setAddress(addressOne);

        return new Object[][] {
            {personSetterOne, 1, true}
        };

//        Person personSetterOne = new Person();
//        personSetterOne.setId(1);
//        personSetterOne.setFirstname("ruchira");
//        personSetterOne.setLastname("reddi");
//        personSetterOne.setEmail("shiv@gmail.com");
//        personSetterOne.setBirthDate(Date.valueOf("2000-12-23"));
//
//        Address addressOne = new Address();
//        addressOne.setStreet("B st");
//        addressOne.setCity("slm");
//        addressOne.setPostalCode(457576);
//        personSetterOne.setAddress(addressOne);
//
//        Person personSetterTwo = new Person();
//        personSetterTwo.setId(1);
//        personSetterTwo.setFirstname("selva");
//        personSetterTwo.setLastname("rani");
//        personSetterTwo.setEmail("rani@gmail.com");
//        personSetterTwo.setBirthDate(Date.valueOf("1974-12-07"));
//
//        Address addressTwo = new Address();
//        addressTwo.setStreet("C st");
//        addressTwo.setCity("slm");
//        addressTwo.setPostalCode(457576);
//        personSetterTwo.setAddress(addressTwo);
    }

    //    @Test(dataProvider = "testGet_negativedp")
    //    private void testGet_negative(String url, AppException expected) throws Exception {
    //        String actualResult = helper.setMethod(HttpMethod.GET)
    //                .requestString(url);
    //        Assert.assertEquals(actualResult,  JsonUtil.toJson(expected.toString()));
    //    }
    //    @DataProvider
    //    private Object[][] testGet_negativedp() {
    //
    //        AppException error = new AppException(Error.URL_ERR);
    //        return new Object[][] {
    //                { "http://localhost:8080/address?id=", error}
    ////            { "http://localhost:8080/address?sd", Error.ID_INVALID},
    ////            { "http://localhost:8080/address?id=", Error.ID_NULL}
    //        };
    //    }

    @Test(dataProvider = "testGetAll_dp")
    private void testGetAll_positive(ArrayList<Person> person) throws Exception {

//        String actualResult = helper.setMethod(HttpMethod.GET)
//                .requestString("http://localhost:8080/ws/person");
        String uri = new StringBuilder().append("http://localhost:8080/ws/person")
                .toString();
        String actualResult = helper.requestString(uri);
        Assert.assertEquals( actualResult, JsonUtil.toJson(person));

    }

    @DataProvider
    private Object[][] testGetAll_dp() {
        Person personSetterOne = new Person();
        personSetterOne.setId(1);
        personSetterOne.setFirstname("ruchira");
        personSetterOne.setLastname("reddi");
        personSetterOne.setEmail("shiv@gmail.com");
        personSetterOne.setBirthDate(Date.valueOf("2000-12-23"));
        personSetterOne.setAddressId(1);

        Address addressOne = new Address();
        addressOne.setId(1);
        addressOne.setStreet("B st");
        addressOne.setCity("slm");
        addressOne.setPostalCode(458525);
        personSetterOne.setAddress(addressOne);
        
        Person personSetterTwo = new Person();
        personSetterTwo.setId(2);
        personSetterTwo.setFirstname("selva");
        personSetterTwo.setLastname("rani");
        personSetterTwo.setEmail("rani@gmail.com");
        personSetterTwo.setBirthDate(Date.valueOf("1974-12-07"));
        personSetterTwo.setAddressId(2);

        Address addressTwo = new Address();
        addressTwo.setId(2);
        addressTwo.setStreet("C st");
        addressTwo.setCity("slm");
        addressTwo.setPostalCode(875452);
        personSetterTwo.setAddress(addressTwo);

        ArrayList<Person> persons = new ArrayList<>();
        persons.add(personSetterOne);
        persons.add(personSetterTwo);
        return new Object[][] {
            {persons}
        };
    }

    @Test
    private void testDelete_positive() throws Exception {

        long expectedValue = 1;
        long actualResult = helper.setMethod(HttpMethod.DELETE)
                .requestObject(String.format("http://localhost:8080/ws/person?id=%d", expectedValue), Long.class);
        Assert.assertEquals(JsonUtil.toJson(actualResult), JsonUtil.toJson(expectedValue));

    }

    @AfterClass
    private void Teardown() throws Exception {
        helper = null;
    }
}
