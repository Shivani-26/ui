package com.ofs.training.test;

import java.net.URI;
import java.net.URL;

import org.apache.http.HttpResponse;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.util.resource.Resource;
import org.eclipse.jetty.webapp.WebAppContext;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.ofs.training.resource.HttpMethod;
import com.ofs.training.resource.RequestHelper;
import com.ofs.training.service.AppException;
import com.ofs.training.service.Person;


public class TestBaseServlet {
    Person person; //initialize your person with credentials
    protected RequestHelper login() { return login(person); }
    protected RequestHelper login(Person person) {

    try {

        RequestHelper helper = RequestHelper.create();
        //Prepare your login call here, if you have implemented it in a different HTTP Method
        HttpResponse response = helper.setMethod(HttpMethod.GET).setInput(person).requestRaw("email = shiv@gmail.com & password = shiv26");
        log(RequestHelper.asString(response));
        Assert.assertEquals(RequestHelper.getStatus(response), 200);
        helper.setSecureDetails(response);
        return helper;
    } catch (Exception e) {
        throw new AppException(e);
    }
}

    private static Server server;
    private static int port = 8080;
    private static String contextPath = "/ws";

    @BeforeSuite
    protected void initServer() throws Exception {

        server = new Server(port);

        URL webXmlResource = server.getClass().getClassLoader().getResource("WEB-INF/web.xml");
        URI webResourceBase = webXmlResource.toURI().resolve("..").normalize();

        log("Using BaseResource: " + webResourceBase);
        WebAppContext context = new WebAppContext();
        context.setBaseResource(Resource.newResource(webResourceBase));

        context.setContextPath(contextPath);
        context.setParentLoaderPriority(true);
        server.setHandler(context);
        server.start();

        String baseUrl = String.format("http://localhost:%s%s", port, contextPath);
            RequestHelper.setBaseUrl(baseUrl);
        }

        @AfterSuite
        protected void stopServer() throws Exception {
            server.stop();
        }
        
        void log(String message) {
            System.out.println(message);
        }
} 

